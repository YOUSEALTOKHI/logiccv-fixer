import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Moon, Sun, Globe, Check, Settings, LogOut, User } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"
import { useAuth } from "@/lib/auth/auth-context"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const { language, setLanguage, t, dir } = useLanguage()
  const { user, signOut } = useAuth()
  const navigate = useNavigate()

  const navLinks = [
    { href: "#how-it-works", label: t.nav.howItWorks },
    { href: "#features", label: t.nav.features },
    { href: "#pricing", label: t.nav.pricing },
    { href: "#", label: t.nav.blog },
    { href: "#", label: t.nav.about },
  ]

  const handleSignOut = async () => {
    await signOut()
    navigate("/")
  }

  return (
    <header
      className="sticky top-0 z-50 w-full h-20 border-b border-border/60 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/70"
      dir={dir}
    >
      <div className="container mx-auto flex h-full items-center justify-between px-4 lg:px-6">
        <Link to="/" className="flex items-center gap-2">
          <LogicCVLogo size="md" />
        </Link>

        <nav className="hidden md:flex items-center gap-8 mx-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-bold text-foreground/80 hover:text-primary transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-foreground hover:bg-muted">
                <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme("light")} className="flex items-center gap-2">
                <Sun className="w-4 h-4" /> Light {theme === "light" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")} className="flex items-center gap-2">
                <Moon className="w-4 h-4" /> Dark {theme === "dark" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")} className="flex items-center gap-2">
                <Settings className="w-4 h-4" /> System {theme === "system" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-foreground hover:bg-muted">
                <Globe className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setLanguage("en")} className="flex items-center gap-2">
                EN English {language === "en" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage("ar")} className="flex items-center gap-2">
                AR العربية {language === "ar" && <Check className="w-4 h-4 ms-auto" />}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="hover:bg-muted gap-2">
                  <Avatar className="w-7 h-7">
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                      <User className="w-3.5 h-3.5" />
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                  {t.nav.dashboard}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/dashboard/settings")}>
                  <Settings className="w-4 h-4 mr-2" />Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="w-4 h-4 mr-2" />{t.nav.logout}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button variant="ghost" className="font-bold" onClick={() => navigate("/login")}>
                {t.nav.login}
              </Button>
              <Button
                className="rounded-full px-6 font-bold shadow-lg shadow-primary/20 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => navigate("/signup")}
              >
                {t.nav.signup}
              </Button>
            </>
          )}
        </div>

        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" className="text-foreground">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side={dir === 'rtl' ? 'left' : 'right'} className="w-[300px] bg-background">
            <div className="flex flex-col gap-6 mt-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-lg font-bold hover:text-primary transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <div className="flex items-center gap-2 py-4 border-t border-border">
                <Button variant="outline" size="sm" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="flex-1">
                  {theme === 'dark' ? <Sun className="w-4 h-4 me-2" /> : <Moon className="w-4 h-4 me-2" />}
                  {theme === 'dark' ? 'Light' : 'Dark'}
                </Button>
                <Button variant="outline" size="sm" onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} className="flex-1">
                  <Globe className="w-4 h-4 me-2" />
                  {language === 'en' ? 'العربية' : 'English'}
                </Button>
              </div>
              <div className="border-t border-border pt-6 flex flex-col gap-3">
                {user ? (
                  <>
                    <Button className="bg-primary text-primary-foreground rounded-full font-bold" onClick={() => { navigate("/dashboard"); setIsOpen(false) }}>
                      {t.nav.dashboard}
                    </Button>
                    <Button variant="ghost" onClick={() => { handleSignOut(); setIsOpen(false) }}>
                      {t.nav.logout}
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="ghost" className="justify-start font-bold" onClick={() => { navigate("/login"); setIsOpen(false) }}>
                      {t.nav.login}
                    </Button>
                    <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full font-bold shadow-lg shadow-primary/20" onClick={() => { navigate("/signup"); setIsOpen(false) }}>
                      {t.nav.signup}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
