export type Language = 'en' | 'ar'

export interface Translations {
  nav: any
  hero: any
  features: any
  pricing: any
  builder: any
  matcher: any
  cta: any
  trust: any
  footer: any
  dashboard: any
  [key: string]: any
}

const en = {
  nav: {
    home: 'Home', howItWorks: 'How It Works', features: 'Features',
    pricing: 'Pricing', about: 'About', blog: 'Blog', careers: 'Careers',
    login: 'Login', signup: 'Sign Up', dashboard: 'Dashboard', logout: 'Logout',
    builder: 'CV Builder', matcher: 'Job Matcher', getStarted: 'Get Started',
  },
  hero: {
    freeTool: 'Free ATS Scan',
    upload: 'Upload CV', uploadDesc: 'PDF, Word, or Text',
    analyzing: 'Analyzing with AI...', scanNow: 'Scan Now',
    atsCompat: 'ATS Compatibility', improveScore: 'Improve Score',
  },
  features: {
    title: 'Everything you need to get hired',
    subtitle: 'AI-powered tools that make the job application process effortless.',
    ats: { title: 'Free ATS Scan', desc: 'Analyze resume compatibility with ATS systems instantly.' },
    matcher: { title: 'Job Matcher', desc: 'Compare your CV with a job description to see your match percentage.' },
    salary: { title: 'Salary Predictor', desc: 'Predict your expected salary based on experience and skills.' },
    gap: { title: 'Skill Gap Analysis', desc: 'Discover missing skills and get course recommendations.' },
    writing: { title: 'Professional Writing', desc: 'Get a custom-written CV from our team of experts.' },
    builder: { title: 'AI CV Builder', desc: 'Create a professional CV in minutes with AI assistance.' },
  },
  pricing: {
    title: 'Simple, Transparent Pricing',
    subtitle: 'Choose the perfect plan for your career goals.',
  },
  builder: {
    title: 'AI CV Builder', subtitle: 'Create a professional resume with AI assistance',
    personal: 'Personal Info', experience: 'Experience', education: 'Education',
    skills: 'Skills', projects: 'Projects', preview: 'Preview',
    fullName: 'Full Name', profTitle: 'Professional Title', email: 'Email',
    phone: 'Phone', location: 'Location', website: 'Website/LinkedIn',
    summary: 'Professional Summary',
    summaryPlaceholder: 'Briefly describe your professional background and key achievements...',
    addExp: 'Add Experience', addEdu: 'Add Education', addSkill: 'Add Skill',
    addProject: 'Add Project', company: 'Company', position: 'Position',
    startDate: 'Start Date', endDate: 'End Date', current: 'Currently working here',
    description: 'Description', school: 'School/University',
    degree: 'Degree/Field of Study', skillName: 'Skill', skillLevel: 'Level',
    projectName: 'Project Name', projectLink: 'Link (Optional)',
    improve: 'Improve with AI', export: 'Export PDF', save: 'Save CV',
    saved: 'CV saved successfully!', exportSuccess: 'Exported as PDF',
    aiWorking: 'AI is improving your text...', aiSuccess: 'Improved by AI!',
    aiError: 'AI request failed', enterText: 'Please enter some text first',
    template: 'Template', modern: 'Modern', classic: 'Classic', creative: 'Creative',
  },
  matcher: {
    title: 'AI Job Matcher',
    desc: 'Identify keyword gaps and optimize your CV for ATS. Our AI compares your experience with specific job requirements.',
    pasteCv: 'Paste your Resume', pasteCvPlaceholder: 'Paste the full text of your resume here...',
    pasteJob: 'Paste Job Description', pasteJobPlaceholder: 'Paste the job description you are targeting...',
    analyze: 'Analyze Match', analyzing: 'Analyzing...',
    summary: 'Analysis Summary', strengths: 'Strengths',
    gaps: 'Gaps', recommendations: 'Strategic Recommendations',
    matchScore: 'Match Score', errorInput: 'Please provide both resume and job description',
    errorAnalysis: 'Failed to analyze. Please try again.', success: 'Analysis complete!',
    placeholder: 'Fill in both fields and click Analyze to see your match results',
  },
  cta: {
    title: 'Ready to build your future?',
    subtitle: 'Join thousands of professionals who used LogicCV to land their dream job.',
    getStarted: 'Get Started for Free', viewPricing: 'View Pricing',
  },
  trust: {
    title: 'Trusted worldwide', desc: 'Helping professionals land jobs at top companies.',
    atsOptimized: 'ATS-optimized', secure: 'Secure & Private',
    aiPowered: 'AI-Powered', instant: 'Instant Results',
  },
  footer: {
    description: 'The ultimate AI-powered platform for career success. Build, optimize, and land your dream job.',
    product: 'Product', resources: 'Resources', legal: 'Legal',
    rights: 'All rights reserved.',
  },
  dashboard: {
    overview: 'Overview', myResumes: 'My Resumes', builder: 'CV Builder',
    matcher: 'Job Matcher', atsScanner: 'ATS Scanner', aiAssistant: 'AI Assistant',
    reviews: 'My Reviews', subscription: 'Subscription', settings: 'Settings',
    support: 'Support Tickets', signOut: 'Sign Out',
  },
}

const ar = {
  nav: {
    home: 'الرئيسية', howItWorks: 'كيف يعمل', features: 'المميزات',
    pricing: 'الأسعار', about: 'من نحن', blog: 'المدونة', careers: 'الوظائف',
    login: 'تسجيل الدخول', signup: 'إنشاء حساب', dashboard: 'لوحة التحكم', logout: 'تسجيل الخروج',
    builder: 'منشئ السيرة', matcher: 'مطابقة الوظائف', getStarted: 'ابدأ الآن',
  },
  hero: {
    freeTool: 'فحص ATS مجاني',
    upload: 'ارفع سيرتك الذاتية', uploadDesc: 'PDF أو Word أو نص',
    analyzing: 'جاري التحليل بالذكاء الاصطناعي...', scanNow: 'افحص الآن',
    atsCompat: 'توافق ATS', improveScore: 'حسّن نتيجتك',
  },
  features: {
    title: 'كل ما تحتاجه للحصول على وظيفة',
    subtitle: 'أدوات مدعومة بالذكاء الاصطناعي تجعل عملية التقديم للوظائف سلسة.',
    ats: { title: 'فحص ATS مجاني', desc: 'حلل توافق سيرتك الذاتية مع أنظمة ATS فوراً.' },
    matcher: { title: 'مطابقة الوظائف', desc: 'قارن سيرتك الذاتية مع وصف الوظيفة لمعرفة نسبة المطابقة.' },
    salary: { title: 'مقياس الراتب', desc: 'توقع راتبك بناءً على الخبرة والمهارات.' },
    gap: { title: 'تحليل الفجوات المهارية', desc: 'اكتشف المهارات الناقصة واحصل على توصيات.' },
    writing: { title: 'كتابة احترافية', desc: 'احصل على سيرة ذاتية مكتوبة بواسطة خبرائنا.' },
    builder: { title: 'منشئ سيرة بالذكاء الاصطناعي', desc: 'أنشئ سيرة ذاتية احترافية في دقائق.' },
  },
  pricing: {
    title: 'أسعار بسيطة وشفافة',
    subtitle: 'اختر الخطة المثالية لأهدافك المهنية.',
  },
  builder: {
    title: 'منشئ السيرة بالذكاء الاصطناعي', subtitle: 'أنشئ سيرة ذاتية احترافية بمساعدة الذكاء الاصطناعي',
    personal: 'المعلومات الشخصية', experience: 'الخبرات', education: 'التعليم',
    skills: 'المهارات', projects: 'المشاريع', preview: 'معاينة',
    fullName: 'الاسم الكامل', profTitle: 'المسمى الوظيفي', email: 'البريد الإلكتروني',
    phone: 'الهاتف', location: 'الموقع', website: 'الموقع/LinkedIn',
    summary: 'الملخص المهني',
    summaryPlaceholder: 'صف خلفيتك المهنية وأبرز إنجازاتك بإيجاز...',
    addExp: 'إضافة خبرة', addEdu: 'إضافة تعليم', addSkill: 'إضافة مهارة',
    addProject: 'إضافة مشروع', company: 'الشركة', position: 'المنصب',
    startDate: 'تاريخ البدء', endDate: 'تاريخ الانتهاء', current: 'أعمل هنا حالياً',
    description: 'الوصف', school: 'المدرسة/الجامعة',
    degree: 'الدرجة/التخصص', skillName: 'المهارة', skillLevel: 'المستوى',
    projectName: 'اسم المشروع', projectLink: 'الرابط (اختياري)',
    improve: 'حسّن بالذكاء الاصطناعي', export: 'تصدير PDF', save: 'حفظ السيرة',
    saved: 'تم حفظ السيرة بنجاح!', exportSuccess: 'تم التصدير كـ PDF',
    aiWorking: 'الذكاء الاصطناعي يحسّن النص...', aiSuccess: 'تم التحسين بالذكاء الاصطناعي!',
    aiError: 'فشل طلب الذكاء الاصطناعي', enterText: 'يرجى إدخال نص أولاً',
    template: 'القالب', modern: 'عصري', classic: 'كلاسيكي', creative: 'إبداعي',
  },
  matcher: {
    title: 'مطابقة الوظائف بالذكاء الاصطناعي',
    desc: 'حدد الفجوات في الكلمات المفتاحية وحسّن سيرتك الذاتية لـ ATS. يقارن الذكاء الاصطناعي خبرتك بمتطلبات الوظيفة.',
    pasteCv: 'الصق سيرتك الذاتية', pasteCvPlaceholder: 'الصق نص سيرتك الذاتية كاملاً هنا...',
    pasteJob: 'الصق وصف الوظيفة', pasteJobPlaceholder: 'الصق وصف الوظيفة المستهدفة...',
    analyze: 'تحليل المطابقة', analyzing: 'جاري التحليل...',
    summary: 'ملخص التحليل', strengths: 'نقاط القوة',
    gaps: 'الفجوات', recommendations: 'توصيات استراتيجية',
    matchScore: 'نسبة المطابقة', errorInput: 'يرجى إدخال السيرة ووصف الوظيفة',
    errorAnalysis: 'فشل التحليل. حاول مرة أخرى.', success: 'اكتمل التحليل!',
    placeholder: 'املأ الحقلين واضغط تحليل لرؤية نتائج المطابقة',
  },
  cta: {
    title: 'هل أنت مستعد لبناء مستقبلك؟',
    subtitle: 'انضم إلى آلاف المهنيين الذين استخدموا LogicCV للحصول على وظيفة أحلامهم.',
    getStarted: 'ابدأ مجاناً', viewPricing: 'عرض الأسعار',
  },
  trust: {
    title: 'موثوق به عالمياً', desc: 'نساعد المهنيين على الحصول على وظائف في كبرى الشركات.',
    atsOptimized: 'متوافق مع ATS', secure: 'آمن وخصوصي',
    aiPowered: 'مدعوم بالذكاء الاصطناعي', instant: 'نتائج فورية',
  },
  footer: {
    description: 'المنصة الأقوى المدعومة بالذكاء الاصطناعي للنجاح المهني. اِبنِ، حسّن، واحصل على وظيفة أحلامك.',
    product: 'المنتج', resources: 'الموارد', legal: 'قانوني',
    rights: 'جميع الحقوق محفوظة.',
  },
  dashboard: {
    overview: 'نظرة عامة', myResumes: 'سيري الذاتية', builder: 'منشئ السيرة',
    matcher: 'مطابقة الوظائف', atsScanner: 'فحص ATS', aiAssistant: 'مساعد ذكي',
    reviews: 'تقييماتي', subscription: 'الاشتراك', settings: 'الإعدادات',
    support: 'تذاكر الدعم', signOut: 'تسجيل الخروج',
  },
}

export const translations: Record<Language, Translations> = { en, ar }
