interface AdProps { isPremiumUser?: boolean }

export function BannerAd({ isPremiumUser = false }: AdProps) {
  if (isPremiumUser) return null
  return (
    <div className="w-full max-w-5xl mx-auto py-4 px-4">
      <div className="flex items-center justify-center bg-gradient-to-r from-muted/50 to-muted/30 rounded-xl border border-border/50 relative overflow-hidden" style={{ minHeight: "100px" }}>
        <div className="absolute top-2 right-3">
          <span className="text-[10px] text-muted-foreground/50 uppercase tracking-wider">Ad</span>
        </div>
        <div className="text-center">
          <span className="text-xs text-muted-foreground/60">Advertisement Space</span>
          <p className="text-[10px] text-muted-foreground/40 mt-1">Upgrade to remove ads</p>
        </div>
      </div>
    </div>
  )
}
