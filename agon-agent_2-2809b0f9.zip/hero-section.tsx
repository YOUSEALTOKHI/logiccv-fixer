import { useState, useCallback } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useLanguage } from "@/lib/i18n/language-context"
import { Upload, CheckCircle2, Shield, Zap, FileText, ArrowRight, Sparkles, Loader2, BarChart3 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import * as pdfjsLib from "pdfjs-dist"
import pdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url"
import { extractAssistantTextFromSSE, extractJsonFromAssistantText } from "@/lib/ai/sse-response"

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker

interface ATSQuickResult {
  overall_score: number
  ats_compatibility: string
  improvements: string[]
}

export function HeroSection() {
  const { language, dir } = useLanguage()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [isDragging, setIsDragging] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [uploadComplete, setUploadComplete] = useState(false)
  const [isScanning, setIsScanning] = useState(false)
  const [isExtractingText, setIsExtractingText] = useState(false)
  const [quickResult, setQuickResult] = useState<ATSQuickResult | null>(null)
  const [extractedText, setExtractedText] = useState("")

  const handleDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(true) }, [])
  const handleDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(false) }, [])

  const extractTextFromFile = async (file: File): Promise<string> => {
    const ext = file.name.split(".").pop()?.toLowerCase()

    if (ext === "pdf") {
      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
      let fullText = ""

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i)
        const textContent = await page.getTextContent()
        const pageText = textContent.items
          .map((item) => ("str" in item ? item.str : ""))
          .join(" ")
          .replace(/\s+/g, " ")
          .trim()

        if (pageText) {
          fullText += `${pageText}\n`
        }
      }

      return fullText.trim()
    }

    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const text = (e.target?.result as string | null)?.trim() ?? ""
        resolve(text)
      }
      reader.onerror = () => reject(new Error("Failed to read file"))
      reader.readAsText(file)
    })
  }

  const startAnalysis = async (file: File) => {
    setIsAnalyzing(true)
    setIsExtractingText(true)
    setProgress(0)
    setUploadComplete(false)
    setQuickResult(null)
    setExtractedText("")

    const progressPromise = new Promise<void>((resolve) => {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval)
            resolve()
            return 100
          }

          return prev + 10
        })
      }, 200)
    })

    try {
      const [text] = await Promise.all([
        extractTextFromFile(file),
        progressPromise,
      ])

      if (!text.trim()) {
        throw new Error(language === "ar" ? "تعذر استخراج النص من الملف" : "Could not extract text from the file")
      }

      setExtractedText(text.slice(0, 40000))
      setUploadComplete(true)
    } catch (error) {
      toast({
        title: language === "ar" ? "خطأ" : "Error",
        description: error instanceof Error ? error.message : (language === "ar" ? "تعذر تجهيز الملف للفحص" : "Could not prepare the file for scanning"),
        variant: "destructive",
      })
      setUploadedFile(null)
    } finally {
      setIsAnalyzing(false)
      setIsExtractingText(false)
    }
  }

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) { setUploadedFile(file); void startAnalysis(file) }
  }, [language])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) { setUploadedFile(file); void startAnalysis(file) }
  }

  const handleATSScan = async () => {
    if (!extractedText.trim()) {
      toast({
        title: language === "ar" ? "خطأ" : "Error",
        description: language === "ar" ? "لم يتم استخراج نص من الملف" : "Could not extract text from the file",
        variant: "destructive",
      })
      return
    }

    setIsScanning(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          mode: "ats_analysis",
          language,
          messages: [{ role: "user", content: `Analyze this resume for ATS compatibility:\n\n${extractedText}` }],
        }),
      })

      if (!response.ok) {
        const errorBody = await response.text()
        throw new Error(errorBody || "Failed to analyze")
      }

      const rawResponse = await response.text()
      const assistantText = extractAssistantTextFromSSE(rawResponse)
      const parsed = extractJsonFromAssistantText<ATSQuickResult & { improvements?: string[] }>(assistantText)

      setQuickResult({
        overall_score: parsed.overall_score,
        ats_compatibility: parsed.ats_compatibility,
        improvements: parsed.improvements?.slice(0, 3) || [],
      })
    } catch {
      toast({
        title: language === "ar" ? "خطأ" : "Error",
        description: language === "ar" ? "حدث خطأ أثناء الفحص، حاول مرة أخرى" : "An error occurred during scanning, please try again",
        variant: "destructive",
      })
    } finally {
      setIsScanning(false)
    }
  }

  const resetUpload = () => {
    setUploadedFile(null)
    setUploadComplete(false)
    setQuickResult(null)
    setProgress(0)
    setExtractedText("")
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500"
    if (score >= 60) return "text-yellow-500"
    if (score >= 40) return "text-orange-500"
    return "text-red-500"
  }

  const c = language === 'ar' ? {
    badge: "تحسين السيرة الذاتية بالذكاء الاصطناعي",
    title: "حسّن سيرتك الذاتية لنظام", titleHighlight: "ATS",
    subtitle: "اجعل سيرتك الذاتية تتجاوز أنظمة تتبع المتقدمين واحصل على وظيفة أحلامك.",
    stat1: "3x", stat1Label: "مقابلات أكثر", stat2: "+50 ألف", stat2Label: "سيرة ذاتية محسّنة",
    stat3: "95%", stat3Label: "معدل النجاح",
    startScan: "ابدأ الفحص المجاني", viewServices: "عرض الخدمات",
    freeATSScan: "فحص ATS مجاني", uploadText: "ارفع سيرتك الذاتية (PDF أو DOCX)",
    clickUpload: "انقر للرفع أو اسحب وأفلت", fileSize: "PDF, DOCX حتى 10MB",
    uploadButton: "رفع السيرة الذاتية", analyzing: "جاري التحليل...",
    freeAnalysis: "تحليل مجاني", secure: "آمن", instant: "فوري",
    startATSScan: "ابدأ فحص ATS الآن", scanning: "جاري الفحص...",
    uploadAnother: "رفع ملف آخر", viewFullReport: "عرض التقرير الكامل",
    scoreLabel: "نتيجة ATS", topImprovements: "أهم التحسينات:",
  } : {
    badge: "AI-Powered Resume Optimization",
    title: "Optimize Your Resume for the", titleHighlight: "ATS",
    subtitle: "Get your CV past the applicant tracking systems and land your dream job. Our AI analyzes your resume against 30+ parameters.",
    stat1: "3x", stat1Label: "More Interviews", stat2: "50K+", stat2Label: "Resumes Optimized",
    stat3: "95%", stat3Label: "Success Rate",
    startScan: "Start Free Scan", viewServices: "View Services",
    freeATSScan: "Free ATS Scan", uploadText: "Upload Your Resume (PDF or DOCX)",
    clickUpload: "Click to upload or drag and drop", fileSize: "PDF, DOCX up to 10MB",
    uploadButton: "Upload Resume", analyzing: "Analyzing...",
    freeAnalysis: "Free Analysis", secure: "Secure", instant: "Instant",
    startATSScan: "Start ATS Scan Now", scanning: "Scanning...",
    uploadAnother: "Upload Another", viewFullReport: "View Full Report",
    scoreLabel: "ATS Score", topImprovements: "Top Improvements:",
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-secondary py-16 lg:py-24" dir={dir}>
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5"/>
          </pattern></defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      <div className="absolute top-20 start-10 w-20 h-20 bg-accent/20 rounded-full blur-xl animate-pulse" />
      <div className="absolute bottom-20 end-10 w-32 h-32 bg-secondary/30 rounded-full blur-xl animate-pulse" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-start">
            <div className="inline-flex items-center gap-2 bg-accent/20 text-primary-foreground px-4 py-2 rounded-full text-sm mb-6">
              <Sparkles className="w-4 h-4" />{c.badge}
            </div>
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold text-primary-foreground leading-tight mb-6 text-balance">
              {c.title}{" "}<span className="text-accent">{c.titleHighlight}</span>
            </h1>
            <p className="text-lg lg:text-xl text-primary-foreground/80 mb-8 leading-relaxed max-w-xl">{c.subtitle}</p>
            <div className="flex flex-wrap justify-center lg:justify-start gap-8 mb-8">
              {[[c.stat1, c.stat1Label], [c.stat2, c.stat2Label], [c.stat3, c.stat3Label]].map(([val, label], i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl font-bold text-accent">{val}</div>
                  <div className="text-sm text-primary-foreground/70">{label}</div>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap justify-center lg:justify-start gap-4">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                {c.startScan}<ArrowRight className="w-4 h-4 ms-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                {c.viewServices}
              </Button>
            </div>
          </div>

          <div className="flex justify-center">
            <Card className="w-full max-w-md bg-card/95 backdrop-blur shadow-2xl border-0">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-foreground mb-2">{c.freeATSScan}</h2>
                  <p className="text-sm text-muted-foreground">{c.uploadText}</p>
                </div>

                {/* Quick Result Display */}
                {quickResult ? (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className={`text-5xl font-bold ${getScoreColor(quickResult.overall_score)}`}>
                        {quickResult.overall_score}%
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{c.scoreLabel}</p>
                    </div>
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          quickResult.overall_score >= 80 ? "bg-green-500" :
                          quickResult.overall_score >= 60 ? "bg-yellow-500" :
                          quickResult.overall_score >= 40 ? "bg-orange-500" : "bg-red-500"
                        }`}
                        style={{ width: `${quickResult.overall_score}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">{quickResult.ats_compatibility}</p>
                    {quickResult.improvements.length > 0 && (
                      <div>
                        <p className="text-sm font-semibold text-foreground mb-2">{c.topImprovements}</p>
                        <ul className="space-y-1">
                          {quickResult.improvements.map((item, i) => (
                            <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                              <span className="text-destructive mt-0.5">•</span>{item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <div className="flex gap-2 mt-4">
                      <Button onClick={() => navigate("/signup")} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                        <BarChart3 className="w-4 h-4 me-2" />{c.viewFullReport}
                      </Button>
                      <Button onClick={resetUpload} variant="outline" className="flex-1">
                        {c.uploadAnother}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className={`relative border-2 border-dashed rounded-xl p-8 transition-all cursor-pointer ${
                      isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/50"
                    }`} onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}>
                      <input type="file" accept=".pdf,.docx,.txt" onChange={handleFileSelect} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                      {uploadedFile ? (
                        <div className="text-center">
                          <FileText className="w-12 h-12 mx-auto text-primary mb-3" />
                          <p className="font-medium text-foreground">{uploadedFile.name}</p>
                          {isAnalyzing && (
                            <div className="mt-4">
                              <Progress value={progress} className="h-2" />
                              <p className="text-sm text-muted-foreground mt-2">{c.analyzing} {progress}%</p>
                            </div>
                          )}
                          {uploadComplete && !isScanning && (
                            <div className="mt-3">
                              <CheckCircle2 className="w-6 h-6 mx-auto text-green-500 mb-1" />
                              <p className="text-sm text-green-600 font-medium">
                                {language === 'ar' ? "تم الرفع بنجاح!" : "Upload complete!"}
                              </p>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center">
                          <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                          <p className="font-medium text-foreground mb-1">{c.clickUpload}</p>
                          <p className="text-xs text-muted-foreground">{c.fileSize}</p>
                        </div>
                      )}
                    </div>

                    {/* ATS Scan Button - appears after upload completes */}
                    {uploadComplete && (
                      <Button
                        onClick={handleATSScan}
                        disabled={isScanning}
                        className="w-full mt-4 bg-accent text-accent-foreground hover:bg-accent/90 font-semibold text-base py-5 animate-in fade-in slide-in-from-bottom-2 duration-300"
                      >
                        {isScanning ? (
                          <><Loader2 className="w-5 h-5 me-2 animate-spin" />{c.scanning}</>
                        ) : (
                          <><Sparkles className="w-5 h-5 me-2" />{c.startATSScan}</>
                        )}
                      </Button>
                    )}

                    {!uploadedFile && (
                      <Button className="w-full mt-4 bg-primary text-primary-foreground hover:bg-primary/90">
                        <Upload className="w-4 h-4 me-2" />{c.uploadButton}
                      </Button>
                    )}
                  </>
                )}

                <div className="flex justify-center gap-6 mt-6 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-green-500" />{c.freeAnalysis}</div>
                  <div className="flex items-center gap-1"><Shield className="w-4 h-4 text-green-500" />{c.secure}</div>
                  <div className="flex items-center gap-1"><Zap className="w-4 h-4 text-green-500" />{c.instant}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
