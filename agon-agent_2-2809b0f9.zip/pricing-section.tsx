import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Zap, Clock } from "lucide-react"

const plans = [
  { name: "Free", description: "Perfect for exploring our tools", price: "$0", period: "", features: ["1 Free ATS Scan", "Basic Resume Analysis", "Keyword Suggestions", "Format Check"], buttonText: "Get Started", buttonVariant: "outline" as const, popular: false },
  { name: "Basic", description: "Professional CV writing", price: "$49", period: "/one-time", features: ["Professional CV Writing", "1 Revision Included", "ATS Optimized Format", "48-Hour Delivery", "PDF + DOCX Formats"], buttonText: "Choose Basic", buttonVariant: "outline" as const, popular: false },
  { name: "Pro", description: "Most popular choice", price: "$79", period: "/one-time", features: ["Everything in Basic", "Unlimited Revisions", "Cover Letter Included", "AI Assistant (3 CVs)", "Unlimited ATS Scans", "24-Hour Delivery", "Direct Writer Chat"], buttonText: "Choose Pro", buttonVariant: "default" as const, popular: true },
  { name: "Premium", description: "VIP treatment", price: "$129", period: "/one-time", features: ["Everything in Pro", "AI Assistant (10 CVs)", "Career Consultation", "Interview Prep Session", "Priority Support", "12-Hour Express Delivery"], buttonText: "Choose Premium", buttonVariant: "outline" as const, popular: false },
]

export function PricingSection() {
  return (
    <section id="pricing" className="py-16 lg:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Choose Your Plan</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Flexible pricing for every career stage</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card key={index} className={`relative flex flex-col ${plan.popular ? "border-primary shadow-lg scale-105 z-10" : "border-border"}`}>
              {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2"><Badge className="bg-primary text-primary-foreground px-4 py-1">Most Popular</Badge></div>}
              <CardHeader className="text-center pt-8">
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
                <ul className="space-y-3">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="pt-4">
                <Button variant={plan.buttonVariant} className={`w-full ${plan.popular ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}`}>
                  {plan.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="mt-12 max-w-2xl mx-auto">
          <Card className="bg-gradient-to-r from-accent/10 via-accent/5 to-accent/10 border-accent/30">
            <CardContent className="flex flex-col md:flex-row items-center justify-between gap-6 p-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-accent/20 flex items-center justify-center">
                  <Clock className="w-7 h-7 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-foreground">Need it faster?</h3>
                  <p className="text-sm text-muted-foreground">Get your professional CV in just 24 hours with our express service.</p>
                </div>
              </div>
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90 whitespace-nowrap">
                <Zap className="w-4 h-4 mr-2" />24h Express - $99
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
