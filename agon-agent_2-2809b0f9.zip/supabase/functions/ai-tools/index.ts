import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { mode, payload, language } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const isAr = language === "ar";
    let systemPrompt = "";
    let userPrompt = "";

    if (mode === "job_match") {
      systemPrompt = `You are an expert ATS analyst and career coach. You compare a resume to a target job description and produce a strict JSON evaluation.

Return ONLY valid JSON with this exact shape (no markdown, no extra text):
{
  "matchPercentage": <number 0-100>,
  "summary": "<one paragraph summary>",
  "strengths": ["<strength 1>", "<strength 2>", ...],
  "weaknesses": ["<gap 1>", "<gap 2>", ...],
  "recommendations": ["<actionable rec 1>", "<actionable rec 2>", ...]
}
Be strict. Focus on keyword overlap, required skills, years of experience, and ATS readability.
${isAr ? "Provide all text fields in Arabic." : "Provide all text fields in English."}`;

      userPrompt = `RESUME:\n${payload.resume}\n\nJOB DESCRIPTION:\n${payload.jobDescription}\n\nReturn the JSON evaluation now.`;
    } else if (mode === "improve_text") {
      systemPrompt = `You are a professional resume writer. Improve the user's text to be more impactful, ATS-friendly, and use strong action verbs with quantifiable results.
Return ONLY the improved text — no markdown, no preface, no quotes around it.
${isAr ? "Reply in Arabic." : "Reply in English."}`;
      userPrompt = `Field: ${payload.field || "description"}\nText to improve:\n${payload.text}`;
    } else {
      throw new Error("Unknown mode: " + mode);
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content ?? "";

    if (mode === "job_match") {
      // Extract JSON from possible markdown wrappers
      let jsonText = content.trim();
      const fence = jsonText.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (fence) jsonText = fence[1].trim();
      try {
        const parsed = JSON.parse(jsonText);
        return new Response(JSON.stringify({ result: parsed }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      } catch {
        return new Response(JSON.stringify({ error: "AI returned invalid JSON", raw: content }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({ result: content.trim() }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-tools error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
