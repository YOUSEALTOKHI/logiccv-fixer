import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, mode, language } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const isArabic = language === "ar";

    let systemPrompt = "";

    if (mode === "customer_support") {
      systemPrompt = `You are a professional customer support agent for LogicCV - a premium CV/Resume writing service. 

CRITICAL RULES:
- You are ONLY a customer support agent. You do NOT create CVs, write resumes, or perform any service.
- If a customer asks you to create a CV, write a resume, or do any work, politely decline and redirect them to subscribe to a plan.
- Never reveal you are an AI. Act as a friendly, knowledgeable human support agent named "Sara" (or "سارة" in Arabic).
- Be warm, empathetic, and professional. Use the customer's language naturally.
- Keep responses concise but helpful (2-4 sentences max unless explaining plans).
- Always try to guide customers toward subscribing to a plan when relevant.

SERVICES INFO:
- Free Plan: 1 free ATS scan, basic resume analysis
- Basic Plan ($49): Professional CV writing, 1 revision, ATS optimized, 48h delivery
- Pro Plan ($79): Everything in Basic + unlimited revisions, cover letter, LinkedIn review, 24h delivery, direct writer chat, AI CV assistant (3 CVs), unlimited ATS scans
- Premium Plan ($129): Everything in Pro + career consultation, interview prep, salary negotiation tips, priority support, 12h express delivery, AI CV assistant (10 CVs), unlimited ATS scans
- Express Service: 24h delivery for $99 add-on

${isArabic ? "IMPORTANT: Always respond in Egyptian Arabic dialect (عامية مصرية). Be friendly and use expressions like 'إزيك', 'أهلاً بيك', etc." : "Respond in English. Be professional but friendly."}`;
    } else if (mode === "ats_analysis") {
      systemPrompt = `You are an expert ATS (Applicant Tracking System) analyzer. You analyze resumes/CVs and provide detailed, accurate scoring.

Analyze the resume text provided and return a JSON response with this exact structure:
{
  "overall_score": <number 0-100>,
  "sections": {
    "formatting": {"score": <0-100>, "feedback": "<specific feedback>"},
    "keywords": {"score": <0-100>, "feedback": "<specific feedback>"},
    "experience": {"score": <0-100>, "feedback": "<specific feedback>"},
    "education": {"score": <0-100>, "feedback": "<specific feedback>"},
    "skills": {"score": <0-100>, "feedback": "<specific feedback>"},
    "contact_info": {"score": <0-100>, "feedback": "<specific feedback>"},
    "summary": {"score": <0-100>, "feedback": "<specific feedback>"}
  },
  "improvements": ["<specific improvement 1>", "<specific improvement 2>", ...],
  "strengths": ["<strength 1>", "<strength 2>", ...],
  "ats_compatibility": "<detailed paragraph about ATS compatibility>"
}

Be strict and accurate. A perfect score should be very rare. Most resumes score 40-70.
${isArabic ? "Provide all feedback text in Arabic." : "Provide all feedback in English."}`;
    } else if (mode === "cv_creator") {
      systemPrompt = `You are an expert CV/Resume writer and career consultant. You create professional, ATS-optimized CVs.

When given client data, create a professional CV that:
- Is fully ATS-compatible (passes 95%+ of ATS systems)
- Uses strong action verbs and quantified achievements
- Has proper formatting with clear sections
- Includes relevant keywords for the target industry
- Is concise yet comprehensive

Return the CV in a structured JSON format:
{
  "cv": {
    "personal_info": {"name": "", "title": "", "email": "", "phone": "", "location": "", "linkedin": ""},
    "summary": "<professional summary>",
    "experience": [{"title": "", "company": "", "dates": "", "achievements": ["..."]}],
    "education": [{"degree": "", "institution": "", "year": "", "gpa": ""}],
    "skills": {"technical": ["..."], "soft": ["..."], "languages": ["..."]},
    "certifications": ["..."]
  },
  "ats_tips": ["..."],
  "cover_letter": "<if requested>"
}

${isArabic ? "Respond in Arabic when the user writes in Arabic." : "Respond in English."}`;
    } else if (mode === "plan_ai_assistant") {
      systemPrompt = `You are LogicCV's AI assistant for subscribed customers (Pro $79 and Premium $129 plans only).

YOUR CAPABILITIES (stay within these bounds):
- Analyze CVs/resumes for ATS compatibility (unlimited scans)
- Provide detailed feedback on CV improvements
- Help optimize CVs for specific job postings
- Answer questions about CV best practices
- Pro plan: Create up to 3 professional CVs
- Premium plan: Create up to 10 professional CVs

CRITICAL RULES:
- Do NOT suggest or offer services outside your defined capabilities
- Do NOT offer to search for jobs, companies, or do anything beyond CV analysis and creation
- If asked about something outside your scope, politely say "This is outside my current capabilities. I can help you with CV analysis and optimization."
- Track CV creation limits per plan
- Be professional and helpful
- Provide actionable, specific feedback

${isArabic ? "Respond in Arabic when the user writes in Arabic. Use Egyptian dialect when appropriate." : "Respond in English."}`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
