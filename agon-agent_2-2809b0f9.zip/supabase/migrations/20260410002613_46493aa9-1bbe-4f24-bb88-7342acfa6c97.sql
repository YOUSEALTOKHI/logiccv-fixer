
-- Orders table
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  resume_id uuid REFERENCES public.resumes(id) ON DELETE SET NULL,
  assigned_writer_id uuid,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','assigned','in_progress','completed','cancelled')),
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders" ON public.orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create orders" ON public.orders FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can do everything with orders" ON public.orders FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Employees can view assigned orders" ON public.orders FOR SELECT USING (auth.uid() = assigned_writer_id);
CREATE POLICY "Employees can update assigned orders" ON public.orders FOR UPDATE USING (auth.uid() = assigned_writer_id);

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Marketing pixels table
CREATE TABLE public.marketing_pixels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  pixel_type text NOT NULL CHECK (pixel_type IN ('facebook','google_analytics','google_ads','tiktok','snapchat','twitter','linkedin','custom')),
  pixel_id text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  placement text NOT NULL DEFAULT 'all' CHECK (placement IN ('all','head','body')),
  custom_code text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.marketing_pixels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage pixels" ON public.marketing_pixels FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Pixels are readable for injection" ON public.marketing_pixels FOR SELECT USING (true);

CREATE TRIGGER update_pixels_updated_at BEFORE UPDATE ON public.marketing_pixels FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Payment gateways config table
CREATE TABLE public.payment_gateways (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  provider text NOT NULL CHECK (provider IN ('stripe','paypal','paddle','razorpay','paymob','tap','moyasar','fawry','custom')),
  is_active boolean NOT NULL DEFAULT false,
  config jsonb DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.payment_gateways ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage gateways" ON public.payment_gateways FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_gateways_updated_at BEFORE UPDATE ON public.payment_gateways FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-assign function: round-robin to employees
CREATE OR REPLACE FUNCTION public.auto_assign_order()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  writer_id uuid;
BEGIN
  -- Pick the employee with fewest active orders (round-robin style)
  SELECT ur.user_id INTO writer_id
  FROM public.user_roles ur
  WHERE ur.role = 'employee'
  ORDER BY (
    SELECT COUNT(*) FROM public.orders o
    WHERE o.assigned_writer_id = ur.user_id AND o.status IN ('assigned','in_progress')
  ) ASC, random()
  LIMIT 1;

  IF writer_id IS NOT NULL THEN
    NEW.assigned_writer_id := writer_id;
    NEW.status := 'assigned';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER auto_assign_order_trigger
BEFORE INSERT ON public.orders
FOR EACH ROW
WHEN (NEW.assigned_writer_id IS NULL)
EXECUTE FUNCTION public.auto_assign_order();

-- Enable realtime for orders
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
