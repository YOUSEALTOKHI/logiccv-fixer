
-- Chat conversations table
CREATE TABLE public.chat_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  employee_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'assigned', 'closed')),
  customer_plan subscription_plan NOT NULL DEFAULT 'free',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers view own conversations" ON public.chat_conversations FOR SELECT USING (auth.uid() = customer_id);
CREATE POLICY "Customers create conversations" ON public.chat_conversations FOR INSERT WITH CHECK (auth.uid() = customer_id);
CREATE POLICY "Staff view all conversations" ON public.chat_conversations FOR SELECT USING (has_role(auth.uid(), 'employee'::app_role) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Staff update conversations" ON public.chat_conversations FOR UPDATE USING (has_role(auth.uid(), 'employee'::app_role) OR has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON public.chat_conversations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Chat messages table
CREATE TABLE public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES public.chat_conversations(id) ON DELETE CASCADE NOT NULL,
  sender_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Participants view messages" ON public.chat_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = conversation_id AND (c.customer_id = auth.uid() OR c.employee_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'employee'::app_role)))
);
CREATE POLICY "Participants send messages" ON public.chat_messages FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = conversation_id AND (c.customer_id = auth.uid() OR c.employee_id = auth.uid() OR has_role(auth.uid(), 'employee'::app_role)))
);

-- ATS scans table
CREATE TABLE public.ats_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  resume_id UUID REFERENCES public.resumes(id) ON DELETE SET NULL,
  score INTEGER,
  result JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ats_scans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own scans" ON public.ats_scans FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users create scans" ON public.ats_scans FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins view all scans" ON public.ats_scans FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- CV creation tracking
CREATE TABLE public.cv_creations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  cv_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.cv_creations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own cvs" ON public.cv_creations FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users create cvs" ON public.cv_creations FOR INSERT WITH CHECK (auth.uid() = user_id);
