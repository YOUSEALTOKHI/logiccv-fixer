
-- Create ticket priority enum
CREATE TYPE public.ticket_priority AS ENUM ('low', 'medium', 'high', 'urgent');

-- Create ticket status enum
CREATE TYPE public.ticket_status AS ENUM ('open', 'in_progress', 'waiting_customer', 'resolved', 'closed');

-- Create ticket category enum
CREATE TYPE public.ticket_category AS ENUM ('general', 'billing', 'technical', 'account', 'feature_request', 'bug_report');

-- Create support_tickets table
CREATE TABLE public.support_tickets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  assigned_to UUID,
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  category ticket_category NOT NULL DEFAULT 'general',
  priority ticket_priority NOT NULL DEFAULT 'medium',
  status ticket_status NOT NULL DEFAULT 'open',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create ticket_replies table
CREATE TABLE public.ticket_replies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ticket_id UUID NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ticket_replies ENABLE ROW LEVEL SECURITY;

-- Tickets RLS: Users can view own tickets
CREATE POLICY "Users can view own tickets"
ON public.support_tickets FOR SELECT
USING (auth.uid() = user_id);

-- Tickets RLS: Users can create own tickets
CREATE POLICY "Users can create own tickets"
ON public.support_tickets FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Tickets RLS: Support/Admin can view all tickets
CREATE POLICY "Support can view all tickets"
ON public.support_tickets FOR SELECT
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Tickets RLS: Support/Admin can update all tickets
CREATE POLICY "Support can update all tickets"
ON public.support_tickets FOR UPDATE
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Replies RLS: Users can view replies on own tickets
CREATE POLICY "Users can view replies on own tickets"
ON public.ticket_replies FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.support_tickets
  WHERE support_tickets.id = ticket_replies.ticket_id
  AND (support_tickets.user_id = auth.uid())
));

-- Replies RLS: Support/Admin can view all replies
CREATE POLICY "Support can view all replies"
ON public.ticket_replies FOR SELECT
USING (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'));

-- Replies RLS: Users can insert replies on own tickets
CREATE POLICY "Users can insert replies on own tickets"
ON public.ticket_replies FOR INSERT
WITH CHECK (
  auth.uid() = sender_id
  AND EXISTS (
    SELECT 1 FROM public.support_tickets
    WHERE support_tickets.id = ticket_replies.ticket_id
    AND (support_tickets.user_id = auth.uid())
  )
);

-- Replies RLS: Support/Admin can insert replies
CREATE POLICY "Support can insert replies"
ON public.ticket_replies FOR INSERT
WITH CHECK (
  auth.uid() = sender_id
  AND (has_role(auth.uid(), 'support') OR has_role(auth.uid(), 'admin'))
);

-- Trigger for updated_at
CREATE TRIGGER update_support_tickets_updated_at
BEFORE UPDATE ON public.support_tickets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for ticket replies
ALTER PUBLICATION supabase_realtime ADD TABLE public.ticket_replies;
