import { supabase } from "../supabase/client";

type SignInOptions = {
  redirect_uri?: string;
  extraParams?: Record<string, string>;
};

type OAuthResult = {
  error: any | null;
  redirected: boolean;
  tokens?: any;
};

// Lazy-load lovable auth to avoid top-level await and crash if unavailable
let lovableAuth: any = null;
let lovableLoaded = false;

async function ensureLovableAuth() {
  if (lovableLoaded) return lovableAuth !== null;
  lovableLoaded = true;
  try {
    const mod = await import("@lovable.dev/cloud-auth-js");
    if (mod?.createLovableAuth) {
      lovableAuth = mod.createLovableAuth();
      return true;
    }
  } catch (e) {
    console.warn("Lovable auth not available:", e);
  }
  return false;
}

export const lovable = {
  auth: {
    signInWithOAuth: async (provider: "google" | "apple" | "microsoft", opts?: SignInOptions): Promise<OAuthResult> => {
      const available = await ensureLovableAuth();
      if (!available || !lovableAuth) {
        return { error: new Error("OAuth is not configured. Please use email/password login."), redirected: false };
      }

      try {
        const result = await lovableAuth.signInWithOAuth(provider, {
          redirect_uri: opts?.redirect_uri,
          extraParams: { ...opts?.extraParams },
        });

        if (result.redirected) return result;
        if (result.error) return result;

        if (supabase && result.tokens) {
          try {
            await supabase.auth.setSession(result.tokens);
          } catch (e) {
            return { error: e instanceof Error ? e : new Error(String(e)), redirected: false };
          }
        }
        return result;
      } catch (e) {
        return { error: e instanceof Error ? e : new Error(String(e)), redirected: false };
      }
    },
  },
};
