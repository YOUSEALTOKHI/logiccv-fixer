export function extractAssistantTextFromSSE(rawResponse: string) {
  let assistantText = ""

  for (const rawLine of rawResponse.split(/\r?\n/)) {
    const line = rawLine.trim()

    if (!line.startsWith("data: ")) continue

    const payload = line.slice(6).trim()
    if (!payload || payload === "[DONE]") continue

    try {
      const parsed = JSON.parse(payload)
      const content = parsed.choices?.[0]?.delta?.content
      if (typeof content === "string") {
        assistantText += content
      }
    } catch {
      // Ignore non-JSON SSE keepalive or partial metadata lines.
    }
  }

  return assistantText
}

export function extractJsonFromAssistantText<T>(assistantText: string) {
  const jsonMatch = assistantText.match(/\{[\s\S]*\}/)

  if (!jsonMatch) {
    throw new Error("Could not parse JSON result")
  }

  return JSON.parse(jsonMatch[0]) as T
}
