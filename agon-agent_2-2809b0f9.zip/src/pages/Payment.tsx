import { useState } from "react"
import { useNavigate, useSearchParams } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useLanguage } from "@/lib/i18n/language-context"
import { useAuth } from "@/lib/auth/auth-context"
import { CreditCard, Lock, Shield, CheckCircle2, ArrowLeft, Loader2, Flame } from "lucide-react"

const plans = [
  { id: "basic", name: "Basic", nameAr: "\u0623\u0633\u0627\u0633\u064a", price: 49 },
  { id: "pro", name: "Pro", nameAr: "\u0627\u062d\u062a\u0631\u0627\u0641\u064a", price: 79 },
  { id: "premium", name: "Premium", nameAr: "\u0645\u0645\u064a\u0632", price: 129 },
  { id: "express", name: "3HR VIP Express", nameAr: "\u0637\u0644\u0628 \u0633\u0631\u064a\u0639 VIP", price: 99 },
]

type PaymentMethod = "card" | "paypal" | "stripe" | "wise" | "bank"

export default function PaymentPage() {
  const { language, t, dir } = useLanguage()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const planId = searchParams.get("plan") || "pro"
  const selectedPlan = plans.find(p => p.id === planId) || plans[1]
  const isExpress = planId === "express"

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const [cardNumber, setCardNumber] = useState("")
  const [cardHolder, setCardHolder] = useState("")
  const [expiry, setExpiry] = useState("")
  const [cvv, setCvv] = useState("")

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value.replace(/\D/g, "").slice(0, 16)
    setCardNumber(v.replace(/(\d{4})(?=\d)/g, "$1 "))
  }

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value.replace(/\D/g, "").slice(0, 4)
    setExpiry(v.replace(/(\d{2})(?=\d)/, "$1/"))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)
    await new Promise(resolve => setTimeout(resolve, 2500))
    setIsProcessing(false)
    setIsSuccess(true)
  }

  const paymentMethods: { id: PaymentMethod; label: string; labelAr: string; icon: string }[] = [
    { id: "card", label: "Credit / Debit Card", labelAr: "\u0628\u0637\u0627\u0642\u0629 \u0627\u0626\u062a\u0645\u0627\u0646 / \u062e\u0635\u0645", icon: "\uD83D\uDCB3" },
    { id: "paypal", label: "PayPal", labelAr: "PayPal", icon: "\uD83C\uDDFE" },
    { id: "stripe", label: "Stripe", labelAr: "Stripe", icon: "\uD83D\uDC8E" },
    { id: "wise", label: "Wise Transfer", labelAr: "\u062a\u062d\u0648\u064a\u0644 Wise", icon: "\uD83C\uDF10" },
    { id: "bank", label: "Bank Transfer", labelAr: "\u062a\u062d\u0648\u064a\u0644 \u0628\u0646\u0643\u064a", icon: "\uD83C\uDFE6" },
  ]

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50/80 p-4" dir={dir}>
        <Card className={`w-full max-w-md shadow-xl text-center ${isExpress ? 'border-red-500/30' : ''}`}>
          <CardContent className="p-10">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${isExpress ? 'bg-red-100' : 'bg-green-100'}`}>
              {isExpress ? <Flame className="w-10 h-10 text-red-500" /> : <CheckCircle2 className="w-10 h-10 text-green-600" />}
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">{t.payment.paymentSuccess}</h2>
            <p className="text-muted-foreground mb-2">
              {isExpress
                ? (language === 'ar' ? '\u0637\u0644\u0628\u0643 \u0627\u0644\u0633\u0631\u064a\u0639 \u062a\u0645 \u0627\u0633\u062a\u0644\u0627\u0645\u0647! \u0633\u064a\u062a\u0645 \u062a\u0648\u062c\u064a\u0647\u0647 \u0644\u0623\u062d\u062f \u062e\u0628\u0631\u0627\u0621 VIP \u0641\u0648\u0631\u0627\u064b.' : 'Your express request has been received! It will be assigned to a VIP expert immediately.')
                : t.payment.paymentSuccessDesc}
            </p>
            {isExpress && (
              <Badge className="bg-red-500 text-white mb-6 animate-pulse">
                {language === 'ar' ? '\u26A1 \u0623\u0648\u0644\u0648\u064a\u0629 \u0642\u0635\u0648\u0649 - 3 \u0633\u0627\u0639\u0627\u062a' : '\u26A1 Top Priority - 3 Hours'}
              </Badge>
            )}
            <Button className={`w-full font-semibold mt-4 ${isExpress ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-[#0f2044] text-white hover:bg-[#162d5a]'}`} onClick={() => navigate("/dashboard")}>
              {t.payment.goToDashboard}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50/80 py-8" dir={dir}>
      <div className="container mx-auto px-4 max-w-4xl">
        <Button variant="ghost" className="mb-6 gap-2 text-muted-foreground hover:text-foreground" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
          {language === 'ar' ? '\u0631\u062c\u0648\u0639' : 'Back'}
        </Button>

        {isExpress && (
          <div className="mb-6 bg-gradient-to-r from-red-500/10 via-red-500/15 to-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3">
            <Flame className="w-6 h-6 text-red-500" />
            <div>
              <p className="font-bold text-red-700">{language === 'ar' ? '\u26A1 \u0637\u0644\u0628 \u0633\u0631\u064a\u0639 VIP - 3 \u0633\u0627\u0639\u0627\u062a' : '\u26A1 VIP Express Request - 3 Hours'}</p>
              <p className="text-xs text-red-600/70">{language === 'ar' ? '\u0633\u064a\u062a\u0645 \u062a\u0648\u062c\u064a\u0647 \u0637\u0644\u0628\u0643 \u0641\u0648\u0631\u0627\u064b \u0644\u0623\u062d\u062f \u062e\u0628\u0631\u0627\u0621 VIP \u0627\u0644\u0645\u062a\u0645\u064a\u0632\u064a\u0646' : 'Your request will be immediately assigned to a VIP expert'}</p>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3">
            <Card className={`shadow-lg ${isExpress ? 'border-red-500/30' : 'border-border/60'}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className={`w-5 h-5 ${isExpress ? 'text-red-500' : 'text-[#0f2044]'}`} />
                  {t.payment.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{t.payment.subtitle}</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label className="text-sm font-semibold mb-3 block">{t.payment.paymentMethod}</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {paymentMethods.map(method => (
                        <button key={method.id} type="button" onClick={() => setPaymentMethod(method.id)}
                          className={`p-3 rounded-xl border-2 text-start transition-all duration-200 ${
                            paymentMethod === method.id
                              ? (isExpress ? "border-red-500 bg-red-500/5" : "border-[#0f2044] bg-[#0f2044]/5")
                              : "border-border/40 hover:border-[#0f2044]/30"
                          }`}>
                          <span className="text-lg">{method.icon}</span>
                          <p className="text-xs font-medium mt-1">{language === 'ar' ? method.labelAr : method.label}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {paymentMethod === "card" && (
                    <div className="space-y-4">
                      <div className="flex gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">Visa</Badge>
                        <Badge variant="outline" className="text-xs">Mastercard</Badge>
                        <Badge variant="outline" className="text-xs">Amex</Badge>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">{t.payment.cardNumber}</Label>
                        <Input id="cardNumber" placeholder={t.payment.cardNumberPlaceholder} value={cardNumber} onChange={handleCardNumberChange} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardHolder">{t.payment.cardHolder}</Label>
                        <Input id="cardHolder" placeholder={t.payment.cardHolderPlaceholder} value={cardHolder} onChange={e => setCardHolder(e.target.value)} required />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry">{t.payment.expiryDate}</Label>
                          <Input id="expiry" placeholder={t.payment.expiryPlaceholder} value={expiry} onChange={handleExpiryChange} required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvv">{t.payment.cvv}</Label>
                          <Input id="cvv" placeholder={t.payment.cvvPlaceholder} value={cvv} onChange={e => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))} required />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === "paypal" && (
                    <div className="space-y-4">
                      <div className="bg-blue-50 rounded-xl p-4 text-center border border-blue-100">
                        <p className="text-sm text-blue-700 font-medium">PayPal</p>
                        <p className="text-xs text-blue-600/60 mt-1">{language === 'ar' ? '\u0633\u064a\u062a\u0645 \u062a\u062d\u0648\u064a\u0644\u0643 \u0625\u0644\u0649 PayPal \u0644\u0625\u062a\u0645\u0627\u0645 \u0627\u0644\u062f\u0641\u0639' : 'You will be redirected to PayPal to complete payment'}</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="paypalEmail">{t.payment.paypalEmail}</Label>
                        <Input id="paypalEmail" type="email" placeholder={t.payment.paypalEmailPlaceholder} required />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "stripe" && (
                    <div className="space-y-4">
                      <div className="bg-indigo-50 rounded-xl p-4 text-center border border-indigo-100">
                        <p className="text-sm text-indigo-700 font-medium">Stripe</p>
                        <p className="text-xs text-indigo-600/60 mt-1">{language === 'ar' ? '\u0633\u064a\u062a\u0645 \u062a\u062d\u0648\u064a\u0644\u0643 \u0625\u0644\u0649 Stripe \u0644\u0625\u062a\u0645\u0627\u0645 \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0622\u0645\u0646' : 'You will be redirected to Stripe for secure payment'}</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="stripeEmail">{language === 'ar' ? '\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a' : 'Email'}</Label>
                        <Input id="stripeEmail" type="email" placeholder={t.payment.paypalEmailPlaceholder} required />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "wise" && (
                    <div className="space-y-4">
                      <div className="bg-green-50 rounded-xl p-4 text-center border border-green-100">
                        <p className="text-sm text-green-700 font-medium">Wise</p>
                        <p className="text-xs text-green-600/60 mt-1">{language === 'ar' ? '\u062a\u062d\u0648\u064a\u0644 \u062f\u0648\u0644\u064a \u0628\u0631\u0633\u0648\u0645 \u0645\u0646\u062e\u0641\u0636\u0629' : 'International transfer with low fees'}</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="wiseEmail">{t.payment.wiseAccount}</Label>
                        <Input id="wiseEmail" type="email" placeholder={t.payment.wiseAccountPlaceholder} required />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "bank" && (
                    <div className="space-y-4">
                      <div className="bg-amber-50 rounded-xl p-4 border border-amber-100">
                        <p className="text-sm text-amber-700 font-medium mb-3">{t.payment.bankDetails}</p>
                        <div className="space-y-2 text-xs text-amber-800/70">
                          <div className="flex justify-between"><span className="font-medium">{t.payment.bankName}:</span><span>First National Bank</span></div>
                          <div className="flex justify-between"><span className="font-medium">{t.payment.accountName}:</span><span>LogicCV LLC</span></div>
                          <div className="flex justify-between"><span className="font-medium">{t.payment.accountNumber}:</span><span>XXXX-XXXX-1234</span></div>
                          <div className="flex justify-between"><span className="font-medium">{t.payment.iban}:</span><span>US12XXXX1234567890</span></div>
                          <div className="flex justify-between"><span className="font-medium">{t.payment.swiftCode}:</span><span>FNBUUS33</span></div>
                        </div>
                      </div>
                    </div>
                  )}

                  <Button type="submit" className={`w-full font-semibold py-6 text-base ${isExpress ? 'bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/25' : 'bg-[#0f2044] text-white hover:bg-[#162d5a]'}`} disabled={isProcessing}>
                    {isProcessing ? (
                      <><Loader2 className="w-5 h-5 me-2 animate-spin" />{t.payment.processing}</>
                    ) : (
                      <><Lock className="w-4 h-4 me-2" />{t.payment.payNow} - ${selectedPlan.price}</>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <Card className={`shadow-lg ${isExpress ? 'border-red-500/30' : 'border-border/60'}`}>
              <CardHeader>
                <CardTitle className="text-lg">{t.payment.orderSummary}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">{t.payment.plan}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{language === 'ar' ? selectedPlan.nameAr : selectedPlan.name}</span>
                    {isExpress && <Badge className="bg-red-500 text-white text-[10px] animate-pulse">VIP</Badge>}
                  </div>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">{t.payment.price}</span>
                  <span className="font-semibold">${selectedPlan.price}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center text-lg">
                  <span className="font-bold">{t.payment.total}</span>
                  <span className={`font-bold ${isExpress ? 'text-red-500' : 'text-[#0f2044]'}`}>${selectedPlan.price}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-border/60">
              <CardContent className="p-5 space-y-4">
                <div className="flex items-center gap-2 text-sm">
                  <Shield className="w-5 h-5 text-green-600" />
                  <span className="font-medium">{t.payment.securePayment}</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Lock className="w-3.5 h-3.5" />{t.payment.encrypted}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Shield className="w-3.5 h-3.5" />{t.payment.pciCompliant}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <CheckCircle2 className="w-3.5 h-3.5" />{t.payment.moneyBack}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Shield className="w-3.5 h-3.5" />{t.security.sslSecured}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
