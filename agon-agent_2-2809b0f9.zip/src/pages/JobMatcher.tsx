import { useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useLanguage } from "@/lib/i18n/language-context"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"
import {
  Target, CheckCircle2, XCircle, Lightbulb, Loader2, FileSearch,
  ArrowRight, Briefcase, FileText, Linkedin, Sparkles, Star, Lock, CreditCard
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { Link } from "react-router-dom"

interface MatchResult {
  matchPercentage: number
  summary: string
  strengths: string[]
  weaknesses: string[]
  recommendations: string[]
  linkedinTips?: string[]
}

export default function JobMatcherPage() {
  const { t, language, dir } = useLanguage()
  const { plan } = useAuth()
  const { toast } = useToast()
  const isAr = language === "ar"
  const [resume, setResume] = useState("")
  const [jobDescription, setJobDescription] = useState("")
  const [analyzing, setAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<MatchResult | null>(null)

  const isPremium = plan === "premium"

  const handleAnalyze = async () => {
    if (!resume.trim() || !jobDescription.trim()) {
      toast({ title: t.matcher.errorInput, variant: "destructive" })
      return
    }
    setAnalyzing(true)
    setAnalysis(null)
    try {
      const { data, error } = await supabase.functions.invoke("ai-tools", {
        body: {
          mode: "job_match",
          language,
          payload: { resume, jobDescription },
        },
      })
      if (error) throw error
      if (data?.error) throw new Error(data.error)
      setAnalysis(data.result)
      toast({ title: t.matcher.success })
    } catch (e: any) {
      console.error(e)
      toast({ title: t.matcher.errorAnalysis, description: e.message, variant: "destructive" })
    } finally {
      setAnalyzing(false)
    }
  }

  const scoreColor = (n: number) =>
    n >= 80 ? "text-green-500" : n >= 50 ? "text-yellow-500" : "text-destructive"

  return (
    <DashboardLayout>
      <div className="space-y-8" dir={dir}>
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-3xl lg:text-4xl font-black tracking-tight">{t.matcher.title}</h1>
            <Badge className="bg-primary/10 text-primary border-primary/20" variant="outline">
              <Target className="w-3 h-3 me-1" /> AI
            </Badge>
          </div>
          <p className="text-muted-foreground max-w-3xl leading-relaxed">{t.matcher.desc}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-primary" /> {t.matcher.pasteCv}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <Textarea
                placeholder={t.matcher.pasteCvPlaceholder}
                className="min-h-[180px] resize-none"
                value={resume}
                onChange={(e) => setResume(e.target.value)}
              />
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Briefcase className="w-4 h-4 text-primary" /> {t.matcher.pasteJob}
                </div>
                <Textarea
                  placeholder={t.matcher.pasteJobPlaceholder}
                  className="min-h-[180px] resize-none"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                />
              </div>
              <Button
                className="w-full h-12 text-base font-bold bg-[#1e40af] text-white hover:bg-[#2563eb]"
                onClick={handleAnalyze}
                disabled={analyzing || !resume.trim() || !jobDescription.trim()}
              >
                {analyzing ? (
                  <><Loader2 className="w-4 h-4 me-2 animate-spin" /> {t.matcher.analyzing}</>
                ) : (
                  <>{t.matcher.analyze} <ArrowRight className="w-4 h-4 ms-2" /></>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-6">
            <AnimatePresence mode="wait">
              {analysis ? (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-6"
                >
                  <Card className="border-2">
                    <CardContent className="p-8 flex flex-col items-center text-center">
                      <div className="relative mb-4">
                        <svg className="h-36 w-36 -rotate-90">
                          <circle cx="72" cy="72" r="64" stroke="currentColor" strokeWidth="10"
                            fill="transparent" className="text-muted/20" />
                          <motion.circle
                            cx="72" cy="72" r="64" stroke="currentColor" strokeWidth="10" fill="transparent"
                            strokeDasharray={402.12}
                            initial={{ strokeDashoffset: 402.12 }}
                            animate={{ strokeDashoffset: 402.12 - (402.12 * analysis.matchPercentage) / 100 }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                            className={scoreColor(analysis.matchPercentage)}
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className={cn("text-4xl font-black", scoreColor(analysis.matchPercentage))}>
                            {analysis.matchPercentage}%
                          </span>
                          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                            {t.matcher.matchScore}
                          </span>
                        </div>
                      </div>
                      <p className="text-muted-foreground text-sm leading-relaxed italic">
                        "{analysis.summary}"
                      </p>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Card className="border-green-500/30 bg-green-500/5">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2 text-green-600 dark:text-green-400">
                          <CheckCircle2 className="w-4 h-4" /> {t.matcher.strengths}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          {analysis.strengths?.map((s, i) => (
                            <li key={i} className="flex gap-2"><span className="text-green-500">•</span><span>{s}</span></li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                    <Card className="border-destructive/30 bg-destructive/5">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2 text-destructive">
                          <XCircle className="w-4 h-4" /> {t.matcher.gaps}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          {analysis.weaknesses?.map((w, i) => (
                            <li key={i} className="flex gap-2"><span className="text-destructive">•</span><span>{w}</span></li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="border-primary/30 bg-primary/5">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2 text-primary">
                        <Lightbulb className="w-4 h-4" /> {t.matcher.recommendations}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ol className="space-y-3">
                        {analysis.recommendations?.map((r, i) => (
                          <li key={i} className="flex gap-3 p-3 rounded-lg bg-background border">
                            <span className="w-6 h-6 rounded-full bg-primary/15 text-primary text-xs font-bold flex items-center justify-center shrink-0">
                              {i + 1}
                            </span>
                            <span className="text-sm font-medium leading-relaxed">{r}</span>
                          </li>
                        ))}
                      </ol>
                    </CardContent>
                  </Card>

                  {/* LinkedIn Tips Section */}
                  <Card className="border-[#0077B5]/30 bg-gradient-to-br from-[#0077B5]/5 to-[#0077B5]/10">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2 text-[#0077B5]">
                        <Linkedin className="w-5 h-5" />
                        {isAr ? "نصائح لينكد إن لهذه الوظيفة" : "LinkedIn Tips for This Job"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isPremium ? (
                        <div className="space-y-3">
                          {analysis.linkedinTips ? (
                            analysis.linkedinTips.map((tip, i) => (
                              <div key={i} className="flex gap-3 p-3 rounded-lg bg-white/60 border border-[#0077B5]/10">
                                <div className="w-6 h-6 rounded-full bg-[#0077B5]/15 flex items-center justify-center shrink-0">
                                  <Star className="w-3.5 h-3.5 text-[#0077B5]" />
                                </div>
                                <span className="text-sm font-medium text-[#0077B5]/90 leading-relaxed">{tip}</span>
                              </div>
                            ))
                          ) : (
                            <div className="space-y-2">
                              <div className="flex gap-3 p-3 rounded-lg bg-white/60 border border-[#0077B5]/10">
                                <div className="w-6 h-6 rounded-full bg-[#0077B5]/15 flex items-center justify-center shrink-0">
                                  <Star className="w-3.5 h-3.5 text-[#0077B5]" />
                                </div>
                                <span className="text-sm font-medium text-[#0077B5]/90">
                                  {isAr ? "أضف الكلمات المفتاحية من الوظيفة في عنوانك على لينكد إن" : "Add keywords from the job description to your LinkedIn headline"}
                                </span>
                              </div>
                              <div className="flex gap-3 p-3 rounded-lg bg-white/60 border border-[#0077B5]/10">
                                <div className="w-6 h-6 rounded-full bg-[#0077B5]/15 flex items-center justify-center shrink-0">
                                  <Star className="w-3.5 h-3.5 text-[#0077B5]" />
                                </div>
                                <span className="text-sm font-medium text-[#0077B5]/90">
                                  {isAr ? "حدّث قسم المهارات ليتطابق مع متطلبات الوظيفة" : "Update your skills section to match the job requirements"}
                                </span>
                              </div>
                              <div className="flex gap-3 p-3 rounded-lg bg-white/60 border border-[#0077B5]/10">
                                <div className="w-6 h-6 rounded-full bg-[#0077B5]/15 flex items-center justify-center shrink-0">
                                  <Star className="w-3.5 h-3.5 text-[#0077B5]" />
                                </div>
                                <span className="text-sm font-medium text-[#0077B5]/90">
                                  {isAr ? "اكتب منشور عن خبرتك في المجال المتعلق بالوظيفة" : "Write a post about your experience in the job's field"}
                                </span>
                              </div>
                            </div>
                          )}
                          <div className="mt-3 flex items-center gap-2 text-xs text-[#0077B5]/60">
                            <Sparkles className="w-3.5 h-3.5" />
                            {isAr ? "ميزة حصرية لباقة المميز - تحسين لينكد إن بالذكاء الاصطناعي" : "Premium exclusive — AI LinkedIn optimization"}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-4 space-y-3">
                          <div className="w-12 h-12 rounded-full bg-[#0077B5]/10 flex items-center justify-center mx-auto">
                            <Lock className="w-6 h-6 text-[#0077B5]" />
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {isAr ? "احصل على نصائح مخصصة لتحسين حسابك على لينكد إن لهذه الوظيفة" : "Get personalized LinkedIn optimization tips for this job"}
                          </p>
                          <Link to="/dashboard/subscription">
                            <Button size="sm" className="bg-[#0077B5] text-white hover:bg-[#0077B5]/90 gap-2">
                              <CreditCard className="w-4 h-4" />
                              {isAr ? "ترقية لباقة المميز" : "Upgrade to Premium"}
                            </Button>
                          </Link>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ) : (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col items-center justify-center text-center p-12 space-y-4 border-2 border-dashed rounded-xl bg-muted/20 min-h-[400px]"
                >
                  <div className="p-6 rounded-full bg-muted">
                    <FileSearch className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground max-w-sm">{t.matcher.placeholder}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
