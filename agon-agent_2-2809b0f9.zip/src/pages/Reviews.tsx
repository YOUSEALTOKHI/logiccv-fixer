import { useState } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, CheckCircle2, Briefcase, MapPin, Quote, Filter, ThumbsUp, ChevronDown } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { reviews, type Review } from "@/components/landing/testimonials-section"

const planColors: Record<string, string> = {
  Basic: "bg-blue-50 text-blue-700 border-blue-200",
  Pro: "bg-[#0f2044]/10 text-[#0f2044] border-[#0f2044]/20",
  Premium: "bg-amber-50 text-amber-700 border-amber-200",
  Express: "bg-red-50 text-red-700 border-red-200",
}

const ratingDistribution = [
  { stars: 5, percent: 82, count: 2334 },
  { stars: 4, percent: 12, count: 342 },
  { stars: 3, percent: 4, count: 114 },
  { stars: 2, percent: 1, count: 38 },
  { stars: 1, percent: 1, count: 19 },
]

export default function ReviewsPage() {
  const { language } = useLanguage()
  const isAr = language === 'ar'
  const [filter, setFilter] = useState<string>("all")
  const [visibleCount, setVisibleCount] = useState(10)

  const filteredReviews = filter === "all" ? reviews : reviews.filter(r => r.plan === filter)

  const c = isAr ? {
    title: "تقييمات العملاء", subtitle: "اقرأ تجارب عملائنا الحقيقيين مع LogicCV",
    verified: "مشتري تم التحقق منه", allPlans: "جميع الباقات",
    showMore: "عرض المزيد من التقييمات", ratingTitle: "تقييم العملاء",
    totalReviews: "إجمالي التقييمات", recommend: "يوصون بنا",
    from: "من", reviews: "تقييم",
  } : {
    title: "Customer Reviews", subtitle: "Read real experiences from our verified customers",
    verified: "Verified Purchase", allPlans: "All Plans",
    showMore: "Load More Reviews", ratingTitle: "Customer Rating",
    totalReviews: "Total Reviews", recommend: "Recommend us",
    from: "from", reviews: "reviews",
  }

  return (
    <div className="min-h-screen flex flex-col" dir={isAr ? 'rtl' : 'ltr'}>
      <Header />
      <main className="flex-1 py-12 lg:py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl lg:text-5xl font-bold text-foreground mb-3">{c.title}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{c.subtitle}</p>
            <div className="flex items-center justify-center gap-3 mt-4">
              <div className="flex gap-0.5">{[1,2,3,4,5].map(i => <Star key={i} className="w-6 h-6 fill-amber-400 text-amber-400" />)}</div>
              <span className="text-2xl font-bold text-foreground">4.9</span>
              <span className="text-muted-foreground">{isAr ? 'من 2,847 تقييم' : 'from 2,847 reviews'}</span>
            </div>
          </div>

          {/* Rating Summary + Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <Card className="border-border/60">
              <CardContent className="p-6 text-center">
                <div className="text-6xl font-bold text-foreground mb-2">4.9</div>
                <div className="flex gap-0.5 justify-center mb-2">{[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />)}</div>
                <p className="text-sm text-muted-foreground">{c.ratingTitle}</p>
                <Separator className="my-4" />
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-foreground">2,847</p>
                    <p className="text-xs text-muted-foreground">{c.totalReviews}</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-600">97%</p>
                    <p className="text-xs text-muted-foreground">{c.recommend}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2 border-border/60">
              <CardContent className="p-6">
                <h3 className="font-semibold text-foreground mb-4">{isAr ? 'توزيع التقييمات' : 'Rating Distribution'}</h3>
                <div className="space-y-3">
                  {ratingDistribution.map(item => (
                    <div key={item.stars} className="flex items-center gap-3">
                      <span className="text-sm font-medium text-foreground w-8">{item.stars}★</span>
                      <div className="flex-1 bg-muted rounded-full h-3 overflow-hidden">
                        <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${item.percent}%` }} />
                      </div>
                      <span className="text-sm text-muted-foreground w-16 text-end">{item.percent}%</span>
                      <span className="text-xs text-muted-foreground w-16 text-end">({item.count.toLocaleString()})</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}
              className={filter === "all" ? "bg-[#0f2044] text-white" : ""}>
              {c.allPlans}
            </Button>
            {["Basic", "Pro", "Premium", "Express"].map(plan => (
              <Button key={plan} variant={filter === plan ? "default" : "outline"} size="sm" onClick={() => setFilter(plan)}
                className={filter === plan ? "bg-[#0f2044] text-white" : ""}>
                {plan} {plan === "Express" && <Badge className="bg-red-500 text-white text-[9px] ms-1 px-1">3HR</Badge>}
              </Button>
            ))}
          </div>

          {/* Reviews List */}
          <div className="space-y-4">
            {filteredReviews.slice(0, visibleCount).map((review, i) => (
              <Card key={i} className="border-border/60 hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-12 h-12 shrink-0">
                      <AvatarFallback className={`${review.avatarBg} text-white font-bold`}>{review.initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between flex-wrap gap-2 mb-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-foreground">{isAr ? review.nameAr : review.name}</span>
                          {review.verified && (
                            <Badge variant="outline" className="text-[10px] text-green-600 border-green-200 bg-green-50">
                              <CheckCircle2 className="w-3 h-3 me-0.5" />{c.verified}
                            </Badge>
                          )}
                        </div>
                        <Badge variant="outline" className={`text-[10px] ${planColors[review.plan]}`}>{review.plan}</Badge>
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex gap-0.5">{[...Array(review.rating)].map((_, j) => (<Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />))}</div>
                        <span className="text-xs text-muted-foreground">{new Date(review.date).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                      </div>
                      <h4 className="font-semibold text-foreground mb-2">{isAr ? review.titleAr : review.title}</h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? review.commentAr : review.comment}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Briefcase className="w-3 h-3" />{isAr ? review.roleAr : review.role}</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{isAr ? review.locationAr : review.location}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-3">
                        <Button variant="ghost" size="sm" className="text-xs text-muted-foreground hover:text-foreground gap-1">
                          <ThumbsUp className="w-3.5 h-3.5" />{isAr ? 'مفيد' : 'Helpful'} ({Math.floor(Math.random() * 40) + 8})
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Load More */}
          {visibleCount < filteredReviews.length && (
            <div className="text-center mt-8">
              <Button variant="outline" className="gap-2" onClick={() => setVisibleCount(prev => prev + 10)}>
                <ChevronDown className="w-4 h-4" />{c.showMore}
              </Button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}

function Separator({ className }: { className?: string }) {
  return <div className={`border-t border-border ${className || ''}`} />
}
