import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Star, Loader2, Send, Trash2 } from "lucide-react"

export default function DashboardReviews() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [reviews, setReviews] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [comment, setComment] = useState("")
  const [rating, setRating] = useState(5)
  const [submitting, setSubmitting] = useState(false)

  const loadReviews = async () => {
    if (!user) return
    const { data } = await supabase.from("reviews").select("*").eq("user_id", user.id).order("created_at", { ascending: false })
    setReviews(data || [])
    setLoading(false)
  }

  useEffect(() => { loadReviews() }, [user])

  const handleSubmit = async () => {
    if (!user || !comment.trim()) return
    setSubmitting(true)
    const { error } = await supabase.from("reviews").insert({ user_id: user.id, rating, comment: comment.trim() })
    setSubmitting(false)
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return }
    toast({ title: "Review submitted!", description: "Your review will be visible after approval." })
    setComment("")
    setRating(5)
    loadReviews()
  }

  const handleDelete = async (id: string) => {
    await supabase.from("reviews").delete().eq("id", id)
    toast({ title: "Review deleted" })
    loadReviews()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <h1 className="text-3xl font-bold">My Reviews</h1>

        <Card>
          <CardHeader><CardTitle>Write a Review</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Rating</p>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(i => (
                  <button key={i} onClick={() => setRating(i)} className="focus:outline-none">
                    <Star className={`w-7 h-7 ${i <= rating ? "fill-accent text-accent" : "text-muted-foreground/30"}`} />
                  </button>
                ))}
              </div>
            </div>
            <Textarea placeholder="Share your experience with LogicCV..." value={comment} onChange={e => setComment(e.target.value)} rows={4} />
            <Button onClick={handleSubmit} disabled={submitting || !comment.trim()}>
              {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
              Submit Review
            </Button>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : reviews.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Your Reviews</h2>
            {reviews.map(review => (
              <Card key={review.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex gap-1 mb-2">
                        {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-accent text-accent" />)}
                      </div>
                      <p className="text-foreground">{review.comment}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-muted-foreground">{new Date(review.created_at).toLocaleDateString()}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${review.is_approved ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                          {review.is_approved ? "Approved" : "Pending"}
                        </span>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(review.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
