import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { Users, FileText, Star, CreditCard, Shield, Loader2, Package } from "lucide-react"

export default function AdminPage() {
  const [stats, setStats] = useState({ users: 0, resumes: 0, reviews: 0, subscriptions: 0, orders: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const [u, r, rv, s, o] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("resumes").select("id", { count: "exact", head: true }),
        supabase.from("reviews").select("id", { count: "exact", head: true }),
        supabase.from("subscriptions").select("id", { count: "exact", head: true }),
        supabase.from("orders").select("id", { count: "exact", head: true }),
      ])
      setStats({
        users: u.count ?? 0,
        resumes: r.count ?? 0,
        reviews: rv.count ?? 0,
        subscriptions: s.count ?? 0,
        orders: o.count ?? 0,
      })
      setLoading(false)
    }
    load()
  }, [])

  const cards = [
    { title: "Total Users", value: stats.users, icon: Users, color: "bg-blue-500/10 text-blue-500" },
    { title: "Total Resumes", value: stats.resumes, icon: FileText, color: "bg-green-500/10 text-green-500" },
    { title: "Total Reviews", value: stats.reviews, icon: Star, color: "bg-accent/20 text-accent" },
    { title: "Subscriptions", value: stats.subscriptions, icon: CreditCard, color: "bg-primary/10 text-primary" },
    { title: "Orders", value: stats.orders, icon: Package, color: "bg-accent/20 text-accent-foreground" },
  ]

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {cards.map(card => (
              <Card key={card.title}>
                <CardContent className="p-6 flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${card.color}`}>
                    <card.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{card.value}</p>
                    <p className="text-sm text-muted-foreground">{card.title}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
