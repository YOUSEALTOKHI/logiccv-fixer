import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { FileText, Upload, Trash2, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function ResumesPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [resumes, setResumes] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadResumes = async () => {
    if (!user) return
    const { data } = await supabase.from("resumes").select("*").eq("user_id", user.id).order("created_at", { ascending: false })
    setResumes(data || [])
    setLoading(false)
  }

  useEffect(() => { loadResumes() }, [user])

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    const filePath = `${user.id}/${Date.now()}_${file.name}`
    const { error: uploadErr } = await supabase.storage.from("resumes").upload(filePath, file)
    if (uploadErr) { toast({ title: "Upload failed", description: uploadErr.message, variant: "destructive" }); return }

    const { error } = await supabase.from("resumes").insert({
      user_id: user.id,
      title: file.name.replace(/\.[^/.]+$/, ""),
      file_url: filePath,
      status: "draft" as const,
    })
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return }
    toast({ title: "Resume uploaded!" })
    loadResumes()
  }

  const handleDelete = async (id: string) => {
    await supabase.from("resumes").delete().eq("id", id)
    toast({ title: "Resume deleted" })
    loadResumes()
  }

  const statusColors: Record<string, string> = {
    draft: "bg-muted text-muted-foreground",
    analyzing: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
    failed: "bg-red-100 text-red-700",
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">My Resumes</h1>
          <div>
            <input type="file" accept=".pdf,.docx" id="resume-upload" className="hidden" onChange={handleUpload} />
            <Button onClick={() => document.getElementById("resume-upload")?.click()}>
              <Upload className="w-4 h-4 mr-2" />Upload Resume
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : resumes.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No resumes yet</h3>
              <p className="text-muted-foreground mb-4">Upload your first resume to get started</p>
              <Button onClick={() => document.getElementById("resume-upload")?.click()}>
                <Upload className="w-4 h-4 mr-2" />Upload Resume
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {resumes.map(resume => (
              <Card key={resume.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FileText className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">{resume.title}</h3>
                      <p className="text-sm text-muted-foreground">{new Date(resume.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={statusColors[resume.status]}>{resume.status}</Badge>
                    {resume.ats_score !== null && (
                      <Badge variant="outline">ATS: {resume.ats_score}%</Badge>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(resume.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
