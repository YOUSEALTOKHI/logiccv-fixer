import { useState, useCallback, useEffect } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { Upload, FileText, CheckCircle, AlertTriangle, XCircle, Loader2, Sparkles, Lock, CreditCard } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/lib/i18n/language-context"
import { extractAssistantTextFromSSE, extractJsonFromAssistantText } from "@/lib/ai/sse-response"
import { Link } from "react-router-dom"
import * as pdfjsLib from "pdfjs-dist"
import pdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url"

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker

interface ATSResult {
  overall_score: number
  sections: Record<string, { score: number; feedback: string }>
  improvements: string[]
  strengths: string[]
  ats_compatibility: string
}

export default function ATSScannerPage() {
  const { user, plan } = useAuth()
  const { toast } = useToast()
  const { language } = useLanguage()
  const isAr = language === "ar"
  const [resumeText, setResumeText] = useState("")
  const [loading, setLoading] = useState(false)
  const [fileLoading, setFileLoading] = useState(false)
  const [uploadedFileName, setUploadedFileName] = useState("")
  const [result, setResult] = useState<ATSResult | null>(null)
  const [scanCount, setScanCount] = useState(0)
  

  useEffect(() => {
    if (user) {
      supabase.from("ats_scans").select("id", { count: "exact", head: true }).eq("user_id", user.id).then(({ count }) => {
        setScanCount(count ?? 0)
        
      })
    }
  }, [user])

  const canScan = plan === "pro" || plan === "premium" || scanCount < 1

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    e.target.value = ""

    const ext = file.name.split(".").pop()?.toLowerCase()
    if (ext !== "pdf") {
      toast({ title: isAr ? "صيغة غير مدعومة" : "Unsupported format", description: isAr ? "يرجى رفع ملف PDF" : "Please upload a PDF file", variant: "destructive" })
      return
    }

    setFileLoading(true)
    try {
      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
      let fullText = ""
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i)
        const content = await page.getTextContent()
        fullText += content.items.map((item: any) => item.str).join(" ") + "\n"
      }
      const cleaned = fullText.replace(/\s+/g, " ").trim()
      if (!cleaned) {
        toast({ title: isAr ? "لم يتم العثور على نص" : "No text found", description: isAr ? "الملف فارغ أو يحتوي على صور فقط" : "File is empty or contains only images", variant: "destructive" })
        return
      }
      setResumeText(cleaned)
      setUploadedFileName(file.name)
      toast({ title: isAr ? "تم استخراج النص بنجاح" : "Text extracted successfully" })
    } catch {
      toast({ title: isAr ? "خطأ في قراءة الملف" : "Error reading file", variant: "destructive" })
    } finally {
      setFileLoading(false)
    }
  }

  const handleScan = useCallback(async () => {
    if (!resumeText.trim() || !user) return
    if (!canScan) {
      toast({ title: isAr ? "تم استنفاد الفحص المجاني" : "Free scan used", description: isAr ? "اشترك في باقة للحصول على فحوصات غير محدودة" : "Subscribe to a plan for unlimited scans", variant: "destructive" })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          mode: "ats_analysis",
          language,
          messages: [{ role: "user", content: `Analyze this resume for ATS compatibility:\n\n${resumeText}` }],
        }),
      })

      if (!response.ok) {
        const errorBody = await response.text()
        throw new Error(errorBody || "Failed to analyze")
      }

      const rawResponse = await response.text()
      const assistantText = extractAssistantTextFromSSE(rawResponse)
      const parsed = extractJsonFromAssistantText<ATSResult>(assistantText)

      setResult(parsed)
      setScanCount(prev => prev + 1)

      await supabase.from("ats_scans").insert({
        user_id: user.id,
        score: parsed.overall_score,
        result: parsed as any,
      })
    } catch {
      toast({ title: isAr ? "خطأ في التحليل" : "Analysis Error", description: isAr ? "حاول مرة أخرى" : "Please try again", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }, [resumeText, user, canScan, language, isAr, toast])

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    if (score >= 40) return "text-orange-500"
    return "text-destructive"
  }

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5 text-green-600" />
    if (score >= 50) return <AlertTriangle className="w-5 h-5 text-yellow-600" />
    return <XCircle className="w-5 h-5 text-destructive" />
  }

  const getProgressColor = (score: number) => {
    if (score >= 80) return "bg-green-500"
    if (score >= 60) return "bg-yellow-500"
    if (score >= 40) return "bg-orange-500"
    return "bg-red-500"
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            {isAr ? "فحص ATS للسيرة الذاتية" : "ATS Resume Scanner"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isAr ? "احصل على تقييم دقيق لسيرتك الذاتية وفقاً لمعايير أنظمة تتبع المتقدمين" : "Get an accurate assessment of your resume against Applicant Tracking Systems"}
          </p>
          {plan === "free" && (
            <Badge variant="outline" className="mt-2">
              {isAr ? `${1 - scanCount} فحص مجاني متبقي` : `${1 - scanCount} free scan remaining`}
            </Badge>
          )}
          {(plan === "pro" || plan === "premium") && (
            <Badge className="mt-2 bg-primary text-primary-foreground">
              {isAr ? "فحوصات غير محدودة" : "Unlimited Scans"}
            </Badge>
          )}
        </div>

        {plan === "free" && !canScan && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="py-10 text-center space-y-4">
              <Lock className="w-14 h-14 mx-auto text-primary" />
              <h2 className="text-xl font-bold">
                {isAr ? "لقد استخدمت فحصك المجاني" : "You've used your free scan"}
              </h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                {isAr
                  ? "قم بترقية باقتك إلى Pro أو Premium للحصول على فحوصات ATS غير محدودة مع تحليل مفصّل ونصائح احترافية لتحسين سيرتك الذاتية."
                  : "Upgrade to Pro or Premium for unlimited ATS scans with detailed analysis and professional tips to improve your resume."}
              </p>
              <div className="flex justify-center gap-3">
                <Link to="/dashboard/subscription">
                  <Button className="gap-2">
                    <CreditCard className="w-4 h-4" />
                    {isAr ? "ترقية الباقة" : "Upgrade Plan"}
                  </Button>
                </Link>
              </div>
              <p className="text-xs text-muted-foreground">
                {isAr ? "باقة Pro تبدأ من $79/شهر • فحوصات غير محدودة" : "Pro starts at $79/mo • Unlimited scans"}
              </p>
            </CardContent>
          </Card>
        )}

        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 ${plan === "free" && !canScan ? "opacity-50 pointer-events-none" : ""}`}>
          {/* Input */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                {isAr ? "نص السيرة الذاتية" : "Resume Text"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File Upload */}
              <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                <input type="file" accept=".pdf" id="ats-file-upload" className="hidden" onChange={handleFileUpload} />
                <Button
                  type="button"
                  variant="outline"
                  className="gap-2"
                  disabled={fileLoading}
                  onClick={() => document.getElementById("ats-file-upload")?.click()}
                >
                  {fileLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" />{isAr ? "جاري الاستخراج..." : "Extracting..."}</>
                  ) : (
                    <><Upload className="w-4 h-4" />{isAr ? "رفع ملف PDF" : "Upload PDF File"}</>
                  )}
                </Button>
                {uploadedFileName && (
                  <p className="text-sm text-muted-foreground mt-2">📄 {uploadedFileName}</p>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  {isAr ? "أو الصق نص السيرة الذاتية في المربع أدناه" : "Or paste your resume text below"}
                </p>
              </div>

              <Textarea
                value={resumeText}
                onChange={e => setResumeText(e.target.value)}
                placeholder={isAr ? "الصق نص سيرتك الذاتية هنا..." : "Paste your resume text here..."}
                className="min-h-[250px] text-sm"
                dir={isAr ? "rtl" : "ltr"}
              />
              <Button onClick={handleScan} disabled={loading || !resumeText.trim() || !canScan} className="w-full">
                {loading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{isAr ? "جاري التحليل..." : "Analyzing..."}</>
                ) : (
                  <><Sparkles className="w-4 h-4 mr-2" />{isAr ? "فحص ATS الآن" : "Scan ATS Now"}</>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-4">
            {loading && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
                  <h3 className="text-lg font-semibold">{isAr ? "جاري تحليل سيرتك الذاتية..." : "Analyzing your resume..."}</h3>
                  <p className="text-muted-foreground text-sm mt-2">{isAr ? "قد يستغرق هذا بضع ثوان" : "This may take a few seconds"}</p>
                </CardContent>
              </Card>
            )}

            {result && (
              <>
                {/* Overall Score */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">{isAr ? "النتيجة الإجمالية" : "Overall Score"}</h3>
                      <span className={`text-4xl font-bold ${getScoreColor(result.overall_score)}`}>
                        {result.overall_score}%
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-1000 ${getProgressColor(result.overall_score)}`} style={{ width: `${result.overall_score}%` }} />
                    </div>
                    <p className="text-sm text-muted-foreground mt-3">{result.ats_compatibility}</p>
                  </CardContent>
                </Card>

                {/* Section Scores */}
                <Card>
                  <CardHeader>
                    <CardTitle>{isAr ? "التقييم التفصيلي" : "Detailed Analysis"}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries(result.sections).map(([key, section]) => (
                      <div key={key} className="space-y-1.5">
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center gap-2 capitalize font-medium">
                            {getScoreIcon(section.score)}
                            {key.replace(/_/g, " ")}
                          </span>
                          <span className={`font-semibold ${getScoreColor(section.score)}`}>{section.score}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                          <div className={`h-full rounded-full ${getProgressColor(section.score)}`} style={{ width: `${section.score}%` }} />
                        </div>
                        <p className="text-xs text-muted-foreground">{section.feedback}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Improvements & Strengths */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-600" />
                        {isAr ? "تحسينات مطلوبة" : "Improvements Needed"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {result.improvements.map((item, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-destructive mt-0.5">•</span>{item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        {isAr ? "نقاط القوة" : "Strengths"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {result.strengths.map((item, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-green-600 mt-0.5">•</span>{item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}

            {!result && !loading && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Upload className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold">{isAr ? "الصق سيرتك الذاتية وابدأ الفحص" : "Paste your resume and start scanning"}</h3>
                  <p className="text-muted-foreground text-sm mt-2">{isAr ? "احصل على تقييم دقيق وشامل" : "Get an accurate and comprehensive assessment"}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
