import { useState, useRef, useEffect, useCallback } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/lib/auth/auth-context"
import { Send, Bot, Sparkles, Loader2 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { useToast } from "@/hooks/use-toast"

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function EmployeeCVBotPage() {
  const { user, hasRole } = useAuth()
  const { language } = useLanguage()
  const { toast } = useToast()
  const isAr = language === "ar"
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  const isStaff = hasRole("employee") || hasRole("admin")

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [messages])

  const handleSend = useCallback(async () => {
    if (!input.trim() || loading || !user) return

    const userMsg: Message = { role: "user", content: input }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setInput("")
    setLoading(true)

    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          mode: "cv_creator",
          language,
          messages: newMessages,
        }),
      })

      if (!response.ok) throw new Error("Failed")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantText = ""

      if (reader) {
        setMessages(prev => [...prev, { role: "assistant", content: "" }])
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value, { stream: true })
          const lines = chunk.split("\n")
          for (const line of lines) {
            if (!line.startsWith("data: ") || line.includes("[DONE]")) continue
            try {
              const parsed = JSON.parse(line.slice(6))
              const content = parsed.choices?.[0]?.delta?.content
              if (content) {
                assistantText += content
                setMessages(prev => prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantText } : m))
              }
            } catch {}
          }
        }
      }
    } catch {
      toast({ title: isAr ? "خطأ" : "Error", variant: "destructive" })
    } finally {
      setLoading(false)
    }
  }, [input, messages, loading, user, language, isAr, toast])

  if (!isStaff) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold">{isAr ? "غير مصرح" : "Unauthorized"}</h1>
          <p className="text-muted-foreground">{isAr ? "للموظفين فقط" : "Staff only"}</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Sparkles className="w-7 h-7 text-accent" />
            {isAr ? "بوت إنشاء السيرة الذاتية" : "CV Creator Bot"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isAr ? "أنشئ سير ذاتية احترافية متوافقة مع ATS للعملاء" : "Create professional ATS-compatible CVs for clients"}
          </p>
        </div>

        <Card className="h-[calc(100vh-240px)] flex flex-col">
          <CardContent className="flex-1 p-0 overflow-hidden">
            <ScrollArea className="h-full p-4" ref={scrollRef}>
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="text-center py-12">
                    <Bot className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold">{isAr ? "مرحباً! أنا خبير إنشاء السير الذاتية" : "Hello! I'm the CV Creation Expert"}</h3>
                    <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                      {isAr
                        ? "أعطيني بيانات العميل وهنشئ سيرة ذاتية احترافية تتخطى نظام ATS"
                        : "Give me the client's data and I'll create a professional ATS-passing CV"}
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center mt-6">
                      {[
                        isAr ? "أنشئ سيرة ذاتية جديدة" : "Create a new CV",
                        isAr ? "اختبر ATS" : "Test ATS score",
                        isAr ? "حسن سيرة ذاتية موجودة" : "Improve an existing CV",
                      ].map((q, i) => (
                        <Button key={i} variant="outline" size="sm" onClick={() => setInput(q)}>
                          {q}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    {msg.role === "assistant" && (
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                        <Bot className="w-4 h-4 text-accent" />
                      </div>
                    )}
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap break-words ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}>
                      {msg.content || (loading && i === messages.length - 1 ? "..." : "")}
                    </div>
                  </div>
                ))}

                {loading && messages[messages.length - 1]?.role !== "assistant" && (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span className="text-sm text-muted-foreground">{isAr ? "جاري الإنشاء..." : "Creating..."}</span>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>

          <div className="p-4 border-t">
            <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2">
              <Input value={input} onChange={e => setInput(e.target.value)} placeholder={isAr ? "أدخل بيانات العميل..." : "Enter client data..."} disabled={loading} className="flex-1" />
              <Button type="submit" disabled={!input.trim() || loading}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  )
}
