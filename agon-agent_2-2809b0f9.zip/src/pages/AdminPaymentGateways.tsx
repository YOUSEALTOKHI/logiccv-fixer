import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { supabase } from "@/integrations/supabase/client"
import { CreditCard, Plus, Loader2, Settings } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Gateway {
  id: string; name: string; provider: string; is_active: boolean; config: any
}

const providers = [
  { value: "stripe", label: "Stripe", desc: "Global card payments" },
  { value: "paypal", label: "PayPal", desc: "Global online payments" },
  { value: "paddle", label: "Paddle", desc: "SaaS payment platform" },
  { value: "razorpay", label: "Razorpay", desc: "India payments" },
  { value: "paymob", label: "Paymob", desc: "Middle East & Africa" },
  { value: "tap", label: "Tap Payments", desc: "Middle East" },
  { value: "moyasar", label: "Moyasar", desc: "Saudi Arabia" },
  { value: "fawry", label: "Fawry", desc: "Egypt payments" },
  { value: "custom", label: "Custom", desc: "Custom integration" },
]

export default function AdminPaymentGateways() {
  const [gateways, setGateways] = useState<Gateway[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ name: "", provider: "stripe", api_key: "", secret_key: "", webhook_url: "" })
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    const { data } = await supabase.from("payment_gateways").select("*").order("created_at")
    if (data) setGateways(data as Gateway[])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const addGateway = async () => {
    const { error } = await supabase.from("payment_gateways").insert({
      name: form.name,
      provider: form.provider,
      config: { api_key: form.api_key, secret_key: form.secret_key, webhook_url: form.webhook_url },
    })
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: "Gateway added" }); setDialogOpen(false); load() }
  }

  const toggleActive = async (id: string, is_active: boolean) => {
    await supabase.from("payment_gateways").update({ is_active }).eq("id", id)
    load()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Payment Gateways</h1>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="w-4 h-4 mr-2" />Add Gateway</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Add Payment Gateway</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div><Label>Name</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Stripe Production" /></div>
                <div><Label>Provider</Label>
                  <Select value={form.provider} onValueChange={v => setForm(f => ({ ...f, provider: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{providers.map(p => <SelectItem key={p.value} value={p.value}>{p.label} - {p.desc}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>API Key (Public)</Label><Input value={form.api_key} onChange={e => setForm(f => ({ ...f, api_key: e.target.value }))} placeholder="pk_..." /></div>
                <div><Label>Secret Key</Label><Input type="password" value={form.secret_key} onChange={e => setForm(f => ({ ...f, secret_key: e.target.value }))} placeholder="sk_..." /></div>
                <div><Label>Webhook URL (optional)</Label><Input value={form.webhook_url} onChange={e => setForm(f => ({ ...f, webhook_url: e.target.value }))} placeholder="https://..." /></div>
                <Button className="w-full" onClick={addGateway}>Save Gateway</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gateways.map(gw => (
              <Card key={gw.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{gw.name}</CardTitle>
                    <Switch checked={gw.is_active} onCheckedChange={v => toggleActive(gw.id, v)} />
                  </div>
                  <CardDescription className="capitalize">{gw.provider}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${gw.is_active ? "bg-green-500" : "bg-muted-foreground"}`} />
                    <span className="text-sm text-muted-foreground">{gw.is_active ? "Active" : "Inactive"}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
            {gateways.length === 0 && (
              <Card className="col-span-full">
                <CardContent className="py-12 text-center text-muted-foreground">
                  <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No payment gateways configured yet</p>
                  <p className="text-sm mt-1">Click "Add Gateway" to set up your first payment provider</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
