import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { supabase } from "@/integrations/supabase/client"
import { Users, Loader2, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface UserProfile {
  id: string; user_id: string; full_name: string | null; created_at: string
}

interface UserRole {
  user_id: string; role: string
}

export default function AdminUsers() {
  const [profiles, setProfiles] = useState<UserProfile[]>([])
  const [roles, setRoles] = useState<UserRole[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    const [p, r] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("*"),
    ])
    if (p.data) setProfiles(p.data)
    if (r.data) setRoles(r.data as UserRole[])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const getUserRoles = (userId: string) => roles.filter(r => r.user_id === userId).map(r => r.role)

  const addRole = async (userId: string, role: string) => {
    const existing = roles.find(r => r.user_id === userId && r.role === role)
    if (existing) return
    const { error } = await supabase.from("user_roles").insert([{ user_id: userId, role: role as any }])
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: "Role added" }); load() }
  }

  const roleColors: Record<string, string> = {
    admin: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    user: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
    employee: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    support: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Users Management</h1>
          </div>
          <Button onClick={load} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Refresh</Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <Card>
            <CardHeader><CardTitle>All Users ({profiles.length})</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>User ID</TableHead>
                    <TableHead>Roles</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Add Role</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {profiles.map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.full_name || "—"}</TableCell>
                      <TableCell className="font-mono text-xs">{p.user_id.slice(0, 12)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {getUserRoles(p.user_id).map(r => (
                            <Badge key={r} className={roleColors[r] || ""}>{r}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-xs">{new Date(p.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Select onValueChange={v => addRole(p.user_id, v)}>
                          <SelectTrigger className="w-32"><SelectValue placeholder="Add role" /></SelectTrigger>
                          <SelectContent>
                            {["admin", "employee", "support"].filter(r => !getUserRoles(p.user_id).includes(r)).map(r => (
                              <SelectItem key={r} value={r}>{r}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
