import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { supabase } from "@/integrations/supabase/client"
import { Package, Loader2, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Order {
  id: string; user_id: string; assigned_writer_id: string | null
  status: string; priority: string; notes: string | null
  created_at: string; resume_id: string | null
}

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  assigned: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  in_progress: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  completed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
}

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [writers, setWriters] = useState<{ user_id: string }[]>([])
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    const [o, w] = await Promise.all([
      supabase.from("orders").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("user_id").eq("role", "employee"),
    ])
    if (o.data) setOrders(o.data as Order[])
    if (w.data) setWriters(w.data)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id)
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: "Updated" }); load() }
  }

  const reassign = async (id: string, writerId: string) => {
    const { error } = await supabase.from("orders").update({ assigned_writer_id: writerId }).eq("id", id)
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" })
    else { toast({ title: "Reassigned" }); load() }
  }

  const stats = {
    total: orders.length,
    pending: orders.filter(o => o.status === "pending").length,
    active: orders.filter(o => ["assigned", "in_progress"].includes(o.status)).length,
    completed: orders.filter(o => o.status === "completed").length,
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Orders Management</h1>
          </div>
          <Button onClick={load} variant="outline" size="sm"><RefreshCw className="w-4 h-4 mr-2" />Refresh</Button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Total Orders", value: stats.total, color: "text-primary" },
            { label: "Pending", value: stats.pending, color: "text-yellow-500" },
            { label: "Active", value: stats.active, color: "text-blue-500" },
            { label: "Completed", value: stats.completed, color: "text-green-500" },
          ].map(s => (
            <Card key={s.label}><CardContent className="p-4 text-center">
              <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-sm text-muted-foreground">{s.label}</p>
            </CardContent></Card>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <Card>
            <CardHeader><CardTitle>All Orders</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Writer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map(order => (
                    <TableRow key={order.id}>
                      <TableCell className="font-mono text-xs">{order.id.slice(0, 8)}</TableCell>
                      <TableCell>
                        <Select value={order.status} onValueChange={v => updateStatus(order.id, v)}>
                          <SelectTrigger className="w-32">
                            <Badge className={statusColors[order.status]}>{order.status}</Badge>
                          </SelectTrigger>
                          <SelectContent>
                            {["pending","assigned","in_progress","completed","cancelled"].map(s => (
                              <SelectItem key={s} value={s}>{s}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell><Badge variant="outline">{order.priority}</Badge></TableCell>
                      <TableCell>
                        <Select value={order.assigned_writer_id || ""} onValueChange={v => reassign(order.id, v)}>
                          <SelectTrigger className="w-36"><SelectValue placeholder="Assign" /></SelectTrigger>
                          <SelectContent>
                            {writers.map(w => (
                              <SelectItem key={w.user_id} value={w.user_id}>{w.user_id.slice(0, 8)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-xs">{new Date(order.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="ghost" onClick={() => updateStatus(order.id, "cancelled")}>Cancel</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {orders.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No orders yet</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
