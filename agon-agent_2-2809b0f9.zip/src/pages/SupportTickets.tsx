import { useEffect, useState, useCallback } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { supabase } from "@/integrations/supabase/client"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { MessageSquare, Loader2, Send, TicketCheck, ArrowLeft } from "lucide-react"

interface Ticket {
  id: string
  user_id: string
  assigned_to: string | null
  subject: string
  description: string
  category: string
  priority: string
  status: string
  created_at: string
  updated_at: string
}

interface Reply {
  id: string
  ticket_id: string
  sender_id: string
  message: string
  created_at: string
}

const statusColors: Record<string, string> = {
  open: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  in_progress: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  waiting_customer: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  resolved: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  closed: "bg-muted text-muted-foreground",
}

const priorityColors: Record<string, string> = {
  low: "bg-muted text-muted-foreground",
  medium: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  high: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  urgent: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
}

export default function SupportTicketsPage() {
  const { user, hasRole } = useAuth()
  const { toast } = useToast()
  const isStaff = hasRole("support") || hasRole("admin")

  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null)
  const [replies, setReplies] = useState<Reply[]>([])
  const [replyText, setReplyText] = useState("")
  const [replying, setReplying] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [filter, setFilter] = useState("all")
  const [createForm, setCreateForm] = useState({
    subject: "",
    description: "",
    category: "general" as string,
    priority: "medium" as string,
  })

  const loadTickets = useCallback(async () => {
    setLoading(true)
    let query = supabase.from("support_tickets").select("*").order("created_at", { ascending: false })
    if (filter !== "all") query = query.eq("status", filter as any)
    const { data } = await query
    setTickets((data as Ticket[]) || [])
    setLoading(false)
  }, [filter])

  useEffect(() => { loadTickets() }, [loadTickets])

  const loadReplies = async (ticketId: string) => {
    const { data } = await supabase
      .from("ticket_replies")
      .select("*")
      .eq("ticket_id", ticketId)
      .order("created_at", { ascending: true })
    setReplies((data as Reply[]) || [])
  }

  const openTicket = async (ticket: Ticket) => {
    setSelectedTicket(ticket)
    await loadReplies(ticket.id)
  }

  const handleCreateTicket = async () => {
    if (!user || !createForm.subject.trim() || !createForm.description.trim()) return
    const { error } = await supabase.from("support_tickets").insert({
      user_id: user.id,
      subject: createForm.subject,
      description: createForm.description,
      category: createForm.category as any,
      priority: createForm.priority as any,
    } as any)
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" })
    } else {
      toast({ title: "Ticket Created!" })
      setShowCreate(false)
      setCreateForm({ subject: "", description: "", category: "general", priority: "medium" })
      loadTickets()
    }
  }

  const handleReply = async () => {
    if (!user || !selectedTicket || !replyText.trim()) return
    setReplying(true)
    const { error } = await supabase.from("ticket_replies").insert({
      ticket_id: selectedTicket.id,
      sender_id: user.id,
      message: replyText,
    })
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" })
    } else {
      setReplyText("")
      await loadReplies(selectedTicket.id)
    }
    setReplying(false)
  }

  const updateTicketStatus = async (ticketId: string, status: string) => {
    const { error } = await supabase.from("support_tickets").update({ status: status as any }).eq("id", ticketId)
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" })
    } else {
      toast({ title: "Status Updated" })
      if (selectedTicket) setSelectedTicket({ ...selectedTicket, status })
      loadTickets()
    }
  }

  // Ticket detail view
  if (selectedTicket) {
    return (
      <DashboardLayout>
        <div className="space-y-4">
          <Button variant="ghost" onClick={() => setSelectedTicket(null)} className="gap-2">
            <ArrowLeft className="w-4 h-4" /> Back to Tickets
          </Button>

          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <CardTitle className="text-xl">{selectedTicket.subject}</CardTitle>
                  <div className="flex gap-2 flex-wrap">
                    <Badge className={statusColors[selectedTicket.status]}>{selectedTicket.status.replace("_", " ")}</Badge>
                    <Badge className={priorityColors[selectedTicket.priority]}>{selectedTicket.priority}</Badge>
                    <Badge variant="outline">{selectedTicket.category.replace("_", " ")}</Badge>
                  </div>
                </div>
                {isStaff && (
                  <Select value={selectedTicket.status} onValueChange={v => updateTicketStatus(selectedTicket.id, v)}>
                    <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="waiting_customer">Waiting Customer</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-muted rounded-lg p-4 text-sm whitespace-pre-wrap mb-4">{selectedTicket.description}</div>
              <p className="text-xs text-muted-foreground">Created: {new Date(selectedTicket.created_at).toLocaleString()}</p>
            </CardContent>
          </Card>

          {/* Replies */}
          <Card>
            <CardHeader><CardTitle className="text-base">Replies ({replies.length})</CardTitle></CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[400px]">
                <div className="space-y-3">
                  {replies.map(reply => (
                    <div key={reply.id} className={`rounded-lg p-3 text-sm ${
                      reply.sender_id === user?.id
                        ? "bg-primary/10 border border-primary/20 ml-8"
                        : "bg-muted mr-8"
                    }`}>
                      <p className="whitespace-pre-wrap">{reply.message}</p>
                      <p className="text-[10px] text-muted-foreground mt-2">
                        {reply.sender_id === user?.id ? "You" : "Support"} • {new Date(reply.created_at).toLocaleString()}
                      </p>
                    </div>
                  ))}
                  {replies.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-4">No replies yet</p>
                  )}
                </div>
              </ScrollArea>

              <form onSubmit={e => { e.preventDefault(); handleReply() }} className="flex gap-2 mt-4">
                <Textarea
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  placeholder="Write a reply..."
                  className="flex-1 min-h-[80px]"
                />
                <Button type="submit" disabled={!replyText.trim() || replying} className="self-end">
                  {replying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">Support Tickets</h1>
          </div>
          <div className="flex gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-40"><SelectValue placeholder="Filter" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="waiting_customer">Waiting</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => setShowCreate(true)}>
              <TicketCheck className="w-4 h-4 mr-2" /> New Ticket
            </Button>
          </div>
        </div>

        {/* Create Ticket Dialog */}
        <Dialog open={showCreate} onOpenChange={setShowCreate}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Create Support Ticket</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Subject</label>
                <Input value={createForm.subject} onChange={e => setCreateForm(f => ({ ...f, subject: e.target.value }))} placeholder="Describe your issue briefly" />
              </div>
              <div>
                <label className="text-sm font-medium">Category</label>
                <Select value={createForm.category} onValueChange={v => setCreateForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="billing">Billing</SelectItem>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="account">Account</SelectItem>
                    <SelectItem value="feature_request">Feature Request</SelectItem>
                    <SelectItem value="bug_report">Bug Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Priority</label>
                <Select value={createForm.priority} onValueChange={v => setCreateForm(f => ({ ...f, priority: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Textarea value={createForm.description} onChange={e => setCreateForm(f => ({ ...f, description: e.target.value }))} placeholder="Explain your issue in detail..." rows={5} />
              </div>
              <Button className="w-full" onClick={handleCreateTicket} disabled={!createForm.subject.trim() || !createForm.description.trim()}>
                Submit Ticket
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets.map(ticket => (
                    <TableRow key={ticket.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openTicket(ticket)}>
                      <TableCell className="font-medium max-w-[200px] truncate">{ticket.subject}</TableCell>
                      <TableCell><Badge variant="outline" className="capitalize text-xs">{ticket.category.replace("_", " ")}</Badge></TableCell>
                      <TableCell><Badge className={`text-xs ${priorityColors[ticket.priority]}`}>{ticket.priority}</Badge></TableCell>
                      <TableCell><Badge className={`text-xs ${statusColors[ticket.status]}`}>{ticket.status.replace("_", " ")}</Badge></TableCell>
                      <TableCell className="text-xs text-muted-foreground">{new Date(ticket.created_at).toLocaleDateString()}</TableCell>
                      <TableCell><Button size="sm" variant="ghost">View</Button></TableCell>
                    </TableRow>
                  ))}
                  {tickets.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                        No tickets found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
