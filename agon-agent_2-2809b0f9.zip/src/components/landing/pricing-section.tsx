import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Linkedin, Star, Zap, Flame } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"

const planData = [
  { id: "basic", nameKey: "basic", price: 49, features: ["proWriting", "oneRevision", "atsOptimized", "delivery48", "pdfDocx"], popular: false },
  { id: "pro", nameKey: "pro", price: 79, features: ["everythingBasic", "unlimitedRevisions", "coverLetter", "aiAssistant3", "unlimitedScans", "delivery24", "writerChat"], popular: true },
  { id: "premium", nameKey: "premium", price: 129, features: ["everythingPro", "aiAssistant10", "careerConsult", "interviewPrep", "prioritySupport", "delivery12", "linkedinOptimization", "linkedinEndorsement"], popular: false },
]

export function PricingSection() {
  const { language, t } = useLanguage()
  const navigate = useNavigate()

  const planNames: Record<string, string> = {
    basic: t.pricing.basic, pro: t.pricing.pro, premium: t.pricing.premium,
  }
  const planDescs: Record<string, string> = {
    basic: t.pricing.basicDesc, pro: t.pricing.proDesc, premium: t.pricing.premiumDesc,
  }
  const buttonLabels: Record<string, string> = {
    basic: t.pricing.chooseBasic, pro: t.pricing.choosePro, premium: t.pricing.choosePremium,
  }

  const handleSelectPlan = (planId: string) => {
    navigate(`/payment?plan=${planId}`)
  }

  return (
    <section id="pricing" className="py-16 lg:py-24 bg-gray-50/80">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">{t.pricing.title}</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t.pricing.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {planData.map((plan) => (
            <Card key={plan.id} className={`relative flex flex-col transition-all duration-300 cursor-pointer ${
              plan.popular
                ? "border-[#0f2044] shadow-xl scale-105 z-10 ring-1 ring-[#0f2044]"
                : "border-border/60 hover:shadow-lg hover:-translate-y-1"
            }`}>
              {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2"><Badge className="bg-[#0f2044] text-white px-4 py-1">{t.pricing.mostPopular}</Badge></div>}

              {plan.id === "premium" && (
                <div className="bg-gradient-to-r from-[#0077B5]/10 to-[#0077B5]/5 border-b border-[#0077B5]/20 px-6 py-3 flex items-center gap-2">
                  <Linkedin className="w-4 h-4 text-[#0077B5]" />
                  <span className="text-xs font-semibold text-[#0077B5]">
                    {language === 'ar' ? 'ميزة لينكد إن حصرية' : 'Exclusive LinkedIn Feature'}
                  </span>
                </div>
              )}

              <CardHeader className="text-center pt-8">
                <CardTitle className="text-xl">{planNames[plan.nameKey]}</CardTitle>
                <p className="text-sm text-muted-foreground">{planDescs[plan.nameKey]}</p>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                  <span className="text-muted-foreground">{t.pricing.oneTime}</span>
                </div>
                <ul className="space-y-3">
                  {plan.features.map((f, i) => (
                    <li key={i} className={`flex items-start gap-2 ${
                      (f === "linkedinOptimization" || f === "linkedinEndorsement") ? "bg-[#0077B5]/5 rounded-lg px-2 py-1.5 -mx-2" : ""
                    }`}>
                      {(f === "linkedinOptimization" || f === "linkedinEndorsement") ? (
                        <Star className="w-5 h-5 text-[#0077B5] shrink-0 mt-0.5" />
                      ) : (
                        <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                      )}
                      <span className={`text-sm ${
                        (f === "linkedinOptimization" || f === "linkedinEndorsement") ? "text-[#0077B5] font-medium" : "text-muted-foreground"
                      }`}>{t.pricing.features[f as keyof typeof t.pricing.features]}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="pt-4 flex flex-col gap-2">
                {plan.popular ? (
                  <Button className="w-full bg-[#0f2044] text-white hover:bg-[#162d5a] font-semibold" onClick={() => handleSelectPlan(plan.id)}>
                    {buttonLabels[plan.id]}
                  </Button>
                ) : (
                  <Button variant="outline" className="w-full font-semibold hover:bg-[#0f2044] hover:text-white hover:border-[#0f2044] transition-all duration-300" onClick={() => handleSelectPlan(plan.id)}>
                    {buttonLabels[plan.id]}
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Express Quick Request - 3 Hours */}
        <div className="mt-10 max-w-2xl mx-auto">
          <Card className="border-red-500/30 bg-gradient-to-r from-red-500/5 via-red-500/10 to-red-500/5 shadow-lg shadow-red-500/10 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-red-600 to-red-500" />
            <CardContent className="flex flex-col md:flex-row items-center justify-between gap-6 p-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-red-500/15 flex items-center justify-center relative">
                  <Flame className="w-8 h-8 text-red-500" />
                  <div className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                    {t.pricing.expressBadge}
                  </div>
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground flex items-center gap-2">
                    {t.pricing.expressTitle}
                    <Badge className="bg-red-500 text-white text-[10px] px-2 animate-pulse">
                      {language === 'ar' ? 'سريع' : 'URGENT'}
                    </Badge>
                  </h3>
                  <p className="text-sm text-muted-foreground">{t.pricing.expressDesc}</p>
                </div>
              </div>
              <Button className="bg-red-500 text-white hover:bg-red-600 whitespace-nowrap font-bold shadow-lg shadow-red-500/25 hover:shadow-red-500/40 transition-all duration-300 hover:scale-105" onClick={() => navigate("/payment?plan=express")}>
                <Zap className="w-4 h-4 mr-2" />{t.pricing.expressBtn}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
