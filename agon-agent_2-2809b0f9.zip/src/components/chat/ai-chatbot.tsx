import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { X, Send, Minus } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { LogicCVLogo } from "@/components/ui/logiccv-logo"
import { motion } from "framer-motion"
import { MessageCircle } from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const quickRepliesEn = [
  "What are your pricing plans?",
  "How long does CV delivery take?",
  "What is ATS optimization?",
  "I need help with my order",
]
const quickRepliesAr = [
  "ما هي خطط الأسعار؟",
  "كم يستغرق تسليم السيرة الذاتية؟",
  "ما هو تحسين ATS؟",
  "أحتاج مساعدة في طلبي",
]

export function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showQuickReplies, setShowQuickReplies] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const { language, dir } = useLanguage()
  const isAr = language === "ar"

  const getInitialMessage = useCallback((): Message => ({
    id: "1",
    role: "assistant",
    content: isAr
      ? "أهلاً وسهلاً! 👋 أنا هنا لمساعدتك في أي استفسار عن خدماتنا. كيف يمكنني خدمتك اليوم؟"
      : "Welcome! 👋 I'm here to help you with any questions about LogicCV services. How can I assist you today?",
    timestamp: new Date(),
  }), [isAr])

  useEffect(() => {
    setMessages([getInitialMessage()])
    setShowQuickReplies(true)
  }, [getInitialMessage])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isTyping])

  useEffect(() => {
    if (isOpen && !isMinimized) inputRef.current?.focus()
  }, [isOpen, isMinimized])

  const handleSend = async (text?: string) => {
    const msg = text || input
    if (!msg.trim()) return
    setShowQuickReplies(false)
    const userMsg: Message = { id: Date.now().toString(), role: "user", content: msg, timestamp: new Date() }
    setMessages(prev => [...prev, userMsg])
    setInput("")
    setIsTyping(true)

    try {
      const aiMessages = messages.filter(m => m.id !== "1").map(m => ({ role: m.role, content: m.content }))
      aiMessages.push({ role: "user", content: msg })

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ mode: "customer_support", language, messages: aiMessages }),
      })

      if (!response.ok) throw new Error("Failed")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantText = ""
      const assistantId = (Date.now() + 1).toString()

      setIsTyping(false)
      setMessages(prev => [...prev, { id: assistantId, role: "assistant", content: "", timestamp: new Date() }])

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value, { stream: true })
          const lines = chunk.split("\n")
          for (const line of lines) {
            if (!line.startsWith("data: ") || line.includes("[DONE]")) continue
            try {
              const parsed = JSON.parse(line.slice(6))
              const content = parsed.choices?.[0]?.delta?.content
              if (content) {
                assistantText += content
                setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: assistantText } : m))
              }
            } catch {}
          }
        }
      }
    } catch {
      setIsTyping(false)
      const fallback = isAr
        ? "عذراً، حدث خطأ. يرجى المحاولة مرة أخرى أو التواصل معنا عبر لوحة التحكم."
        : "Sorry, something went wrong. Please try again or contact us through the dashboard."
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: "assistant", content: fallback, timestamp: new Date() }])
    }
  }

  const quickReplies = isAr ? quickRepliesAr : quickRepliesEn

  if (!isOpen) {
    return (
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 group"
        aria-label="Open chat"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        <div className="relative">
          <span className="absolute inset-0 rounded-full bg-primary/30 animate-ping" />
          <motion.div
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            className="relative w-16 h-16 rounded-full bg-primary shadow-xl shadow-primary/30 flex items-center justify-center overflow-hidden"
          >
            <LogicCVLogo size="sm" showText={false} variant="light" />
          </motion.div>
          <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full border-2 border-background" />
        </div>
        <div className="absolute bottom-full right-0 mb-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <div className="bg-card text-card-foreground text-sm font-medium px-3 py-2 rounded-lg shadow-lg border border-border whitespace-nowrap">
            {isAr ? "تحتاج مساعدة؟ 💬" : "Need help? 💬"}
          </div>
        </div>
      </motion.button>
    )
  }

  if (isMinimized) {
    return (
      <div onClick={() => setIsMinimized(false)} className="fixed bottom-6 right-6 z-50 cursor-pointer">
        <div className="flex items-center gap-3 bg-primary text-primary-foreground px-4 py-3 rounded-full shadow-xl hover:shadow-2xl transition-shadow">
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm font-bold">{isAr ? "الدعم" : "LogicCV Support"}</span>
          <span className="w-2 h-2 rounded-full bg-green-400" />
        </div>
      </div>
    )
  }

  return (
    <Card className="fixed bottom-6 right-6 z-50 w-[400px] h-[550px] shadow-2xl flex flex-col overflow-hidden border-border/50 rounded-2xl" dir={dir}>
      <CardHeader className="bg-gradient-to-br from-primary to-primary-glow p-0">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-primary-foreground/15 backdrop-blur flex items-center justify-center shadow-sm">
                <LogicCVLogo size="sm" showText={false} variant="light" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-primary bg-green-500" />
            </div>
            <div>
              <h3 className="text-primary-foreground font-bold text-sm">
                Logic<span className="text-accent">CV</span> {isAr ? "دعم العملاء" : "Support"}
              </h3>
              <p className="text-primary-foreground/80 text-xs">
                {isAr ? "متصل الآن • نرد خلال ثواني" : "Online • Replies instantly"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => setIsMinimized(true)} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/15 w-8 h-8">
              <Minus className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/15 w-8 h-8">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-0 overflow-hidden bg-muted/30">
        <ScrollArea className="h-full" ref={scrollRef}>
          <div className="p-4 space-y-3">
            {messages.map(msg => (
              <div key={msg.id} className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center shadow-sm flex-shrink-0 mt-1 p-0.5">
                    <LogicCVLogo size="sm" showText={false} variant="light" />
                  </div>
                )}
                <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-sm"
                    : "bg-card text-card-foreground border border-border rounded-bl-sm shadow-sm"
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-2 justify-start">
                <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center shadow-sm flex-shrink-0 mt-1 p-0.5">
                  <LogicCVLogo size="sm" showText={false} variant="light" />
                </div>
                <div className="bg-card border border-border rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
                  <div className="flex gap-1.5">
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}

            {showQuickReplies && messages.length <= 1 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {quickReplies.map((q, i) => (
                  <button key={i} onClick={() => handleSend(q)} className="text-xs bg-card border border-border text-foreground px-3 py-2 rounded-full hover:bg-accent hover:text-accent-foreground transition-colors shadow-sm">
                    {q}
                  </button>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>

      <CardFooter className="p-3 border-t border-border bg-card">
        <div className="w-full">
          <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2 w-full items-center">
            <Input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder={isAr ? "اكتب رسالتك..." : "Type your message..."}
              className="flex-1 rounded-full bg-muted border-0 focus-visible:ring-1 focus-visible:ring-primary text-sm"
              disabled={isTyping}
            />
            <Button type="submit" size="icon" disabled={!input.trim() || isTyping} className="rounded-full w-10 h-10 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 flex-shrink-0">
              <Send className={`w-4 h-4 ${isAr ? "rotate-180" : ""}`} />
            </Button>
          </form>
          <p className="text-[10px] text-muted-foreground/50 text-center w-full mt-2">
            {isAr ? "مدعوم بالذكاء الاصطناعي" : "Powered by LogicCV"}
          </p>
        </div>
      </CardFooter>
    </Card>
  )
}
