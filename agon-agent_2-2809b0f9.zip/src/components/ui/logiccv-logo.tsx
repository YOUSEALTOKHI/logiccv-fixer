import { cn } from "@/lib/utils"

interface LogicCVLogoProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  showTagline?: boolean
  variant?: "light" | "dark" | "auto"
}

const SIZE_MAP = {
  sm: { icon: "w-7 h-7", text: "text-base", tagline: "text-[7px] tracking-[0.15em]" },
  md: { icon: "w-9 h-9", text: "text-lg", tagline: "text-[8px] tracking-[0.18em]" },
  lg: { icon: "w-11 h-11", text: "text-2xl", tagline: "text-[9px] tracking-[0.2em]" },
  xl: { icon: "w-14 h-14", text: "text-3xl", tagline: "text-[10px] tracking-[0.22em]" },
}

export function LogicCVLogo({
  className,
  size = "md",
  showText = true,
  showTagline = false,
  variant = "auto",
}: LogicCVLogoProps) {
  const s = SIZE_MAP[size]

  const isLight = variant === "light"
  const textColor = isLight ? "text-white" : "text-[#0a1628] dark:text-white"
  const taglineColor = isLight ? "text-white/50" : "text-[#0a1628]/50 dark:text-white/50"

  return (
    <div className={cn("flex items-center gap-2.5 group cursor-pointer select-none", className)}>
      {/* PCB-style Icon Mark - Interlocking L & C with document checkmark */}
      <div className={cn("relative shrink-0", s.icon)}>
        <div className={cn(
          "w-full h-full rounded-xl flex items-center justify-center shadow-lg transition-transform duration-300 group-hover:scale-105",
          "bg-gradient-to-br from-[#0a1628] via-[#0f2044] to-[#1a3a6a]",
          isLight ? "shadow-black/30" : "shadow-[#0f2044]/20"
        )}>
          <svg
            viewBox="0 0 48 48"
            className="w-[80%] h-[80%]"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* PCB circuit trace lines - background pattern */}
            <path d="M6 14H14V6" stroke="#1e4d8c" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
            <path d="M34 6V14H42" stroke="#1e4d8c" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
            <path d="M6 34H14V42" stroke="#1e4d8c" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
            
            {/* PCB dots / vias */}
            <circle cx="6" cy="14" r="1.5" fill="#2563eb" opacity="0.5" />
            <circle cx="14" cy="6" r="1.5" fill="#2563eb" opacity="0.5" />
            <circle cx="34" cy="6" r="1.5" fill="#2563eb" opacity="0.5" />
            <circle cx="42" cy="14" r="1.5" fill="#2563eb" opacity="0.5" />
            <circle cx="6" cy="34" r="1.5" fill="#2563eb" opacity="0.5" />
            <circle cx="14" cy="42" r="1.5" fill="#2563eb" opacity="0.5" />

            {/* Document shape - the paper/CV being verified */}
            <rect x="14" y="10" width="20" height="28" rx="2" fill="white" opacity="0.1" />
            <rect x="14" y="10" width="20" height="28" rx="2" stroke="white" strokeWidth="1.5" opacity="0.3" />
            
            {/* L letter - vertical stroke with PCB trace style */}
            <path
              d="M17 13V31"
              stroke="url(#lcGradient)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            {/* L letter - horizontal base */}
            <path
              d="M17 31H24"
              stroke="url(#lcGradient)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            
            {/* C letter - interlocking with L, PCB arc style */}
            <path
              d="M33 17C33 13.7 30.3 11 27 11H25"
              stroke="url(#lcGradient2)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            <path
              d="M33 27C33 30.3 30.3 33 27 33H25"
              stroke="url(#lcGradient2)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            {/* C vertical connector */}
            <path
              d="M33 17V27"
              stroke="url(#lcGradient2)"
              strokeWidth="3.5"
              strokeLinecap="round"
            />

            {/* Checkmark - verification/ATS pass symbol */}
            <path
              d="M19 23L23 27L30 18"
              stroke="#38bdf8"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Gradients */}
            <defs>
              <linearGradient id="lcGradient" x1="17" y1="13" x2="24" y2="31" gradientUnits="userSpaceOnUse">
                <stop stopColor="#60a5fa" />
                <stop offset="1" stopColor="#2563eb" />
              </linearGradient>
              <linearGradient id="lcGradient2" x1="25" y1="11" x2="33" y2="33" gradientUnits="userSpaceOnUse">
                <stop stopColor="#38bdf8" />
                <stop offset="1" stopColor="#3b82f6" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* AI Spark indicator */}
        <div className={cn(
          "absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full border-2 flex items-center justify-center bg-sky-400",
          isLight ? "border-[#0a1628]" : "border-white dark:border-[#0a1628]"
        )}>
          <div className="w-1 h-1 rounded-full bg-white animate-pulse" />
        </div>
      </div>

      {/* Wordmark */}
      {showText && (
        <div className="flex flex-col leading-none">
          <div className={cn("font-extrabold tracking-tight", s.text, textColor)}>
            Logic<span className="text-sky-500">CV</span>
          </div>
          {showTagline && (
            <span className={cn("font-semibold uppercase mt-1", s.tagline, taglineColor)}>
              Build. Optimize. Succeed.
            </span>
          )}
        </div>
      )}
    </div>
  )
}
