import { useState, useRef, useEffect, useCallback } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/lib/auth/auth-context"
import { supabase } from "@/integrations/supabase/client"
import { Send, Users, MessageCircle, Loader2 } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { useToast } from "@/hooks/use-toast"

interface Conversation {
  id: string
  customer_id: string
  employee_id: string | null
  status: string
  customer_plan: string
  created_at: string
  customer_name?: string
}

interface ChatMessage {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  is_read: boolean
  created_at: string
}

export default function EmployeeChatPage() {
  const { user, hasRole } = useAuth()
  const { language } = useLanguage()
  const { toast } = useToast()
  const isAr = language === "ar"
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [activeConv, setActiveConv] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)

  const isStaff = hasRole("employee") || hasRole("admin")

  const loadConversations = useCallback(async () => {
    const { data } = await supabase.from("chat_conversations").select("*").order("updated_at", { ascending: false })
    if (data) {
      // Load customer names
      const customerIds = [...new Set(data.map((c: any) => c.customer_id))]
      const { data: profiles } = await supabase.from("profiles").select("user_id, full_name").in("user_id", customerIds)
      const nameMap = new Map(profiles?.map((p: any) => [p.user_id, p.full_name]) || [])
      setConversations(data.map((c: any) => ({ ...c, customer_name: nameMap.get(c.customer_id) || "Customer" })))
    }
    setLoading(false)
  }, [])

  const loadMessages = useCallback(async (convId: string) => {
    const { data } = await supabase.from("chat_messages").select("*").eq("conversation_id", convId).order("created_at", { ascending: true })
    if (data) setMessages(data)
  }, [])

  useEffect(() => { loadConversations() }, [loadConversations])

  useEffect(() => {
    if (activeConv) {
      loadMessages(activeConv.id)
      const channel = supabase.channel(`chat-${activeConv.id}`).on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages", filter: `conversation_id=eq.${activeConv.id}` }, (payload: any) => {
        setMessages(prev => [...prev, payload.new])
      }).subscribe()
      return () => { supabase.removeChannel(channel) }
    }
  }, [activeConv, loadMessages])

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [messages])

  const handleSend = async () => {
    if (!input.trim() || !activeConv || !user) return
    const { error } = await supabase.from("chat_messages").insert({
      conversation_id: activeConv.id,
      sender_id: user.id,
      content: input,
    })
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return }
    setInput("")
  }

  const planBadgeColor: Record<string, string> = {
    free: "bg-muted text-muted-foreground",
    basic: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    pro: "bg-primary/10 text-primary",
    premium: "bg-accent/20 text-accent-foreground border-accent",
  }

  if (!isStaff) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold">{isAr ? "غير مصرح" : "Unauthorized"}</h1>
          <p className="text-muted-foreground">{isAr ? "هذه الصفحة للموظفين فقط" : "This page is for staff only"}</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">{isAr ? "شات العملاء" : "Customer Chat"}</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-220px)]">
          {/* Conversations List */}
          <Card className="lg:col-span-1 flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="w-4 h-4" />
                {isAr ? "المحادثات" : "Conversations"} ({conversations.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              <ScrollArea className="h-full">
                {loading ? (
                  <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
                ) : conversations.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8 text-sm">{isAr ? "لا توجد محادثات" : "No conversations"}</p>
                ) : (
                  <div className="space-y-1 p-2">
                    {conversations.map(conv => (
                      <button
                        key={conv.id}
                        onClick={() => setActiveConv(conv)}
                        className={`w-full text-left p-3 rounded-lg transition-colors ${activeConv?.id === conv.id ? "bg-primary/10 border border-primary/20" : "hover:bg-muted"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm truncate">{conv.customer_name}</span>
                          <Badge className={`text-[10px] px-1.5 py-0.5 ${planBadgeColor[conv.customer_plan] || ""}`}>
                            {conv.customer_plan.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-muted-foreground">
                            {new Date(conv.created_at).toLocaleDateString()}
                          </span>
                          <Badge variant="outline" className="text-[10px]">{conv.status}</Badge>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="lg:col-span-2 flex flex-col">
            {activeConv ? (
              <>
                <CardHeader className="pb-2 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{activeConv.customer_name}</h3>
                        <p className="text-xs text-muted-foreground">{isAr ? "عميل" : "Customer"}</p>
                      </div>
                    </div>
                    <Badge className={planBadgeColor[activeConv.customer_plan] || ""}>
                      {isAr ? `باقة ${activeConv.customer_plan}` : `${activeConv.customer_plan} Plan`}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 p-0 overflow-hidden">
                  <ScrollArea className="h-full p-4" ref={scrollRef}>
                    <div className="space-y-3">
                      {messages.map(msg => (
                        <div key={msg.id} className={`flex ${msg.sender_id === user?.id ? "justify-end" : "justify-start"}`}>
                          <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                            msg.sender_id === user?.id
                              ? "bg-primary text-primary-foreground rounded-br-sm"
                              : "bg-muted text-foreground rounded-bl-sm"
                          }`}>
                            {msg.content}
                            <p className="text-[10px] mt-1 opacity-60">
                              {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
                <div className="p-3 border-t">
                  <form onSubmit={e => { e.preventDefault(); handleSend() }} className="flex gap-2">
                    <Input value={input} onChange={e => setInput(e.target.value)} placeholder={isAr ? "اكتب رسالتك..." : "Type a message..."} className="flex-1" />
                    <Button type="submit" size="icon" disabled={!input.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold">{isAr ? "اختر محادثة" : "Select a conversation"}</h3>
                  <p className="text-muted-foreground text-sm">{isAr ? "اختر محادثة من القائمة للبدء" : "Choose a conversation from the list to start"}</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
