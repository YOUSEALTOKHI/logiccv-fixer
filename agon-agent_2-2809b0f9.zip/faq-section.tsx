import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  { question: "What is an ATS and why does my resume need to be ATS-friendly?", answer: "An ATS (Applicant Tracking System) is software used by employers to collect, scan, and rank job applications. Over 98% of Fortune 500 companies use ATS. Our tool ensures your resume is optimized to pass these systems." },
  { question: "How does the free ATS scanner work?", answer: "Upload your resume in PDF or DOCX format. Our AI-powered scanner analyzes your resume against 30+ parameters. Within seconds, you'll receive a detailed report with your ATS compatibility score." },
  { question: "What's included in the professional CV writing service?", answer: "A consultation, professionally written resume, ATS optimization, keyword enhancement, proper formatting, and revisions. You'll receive your resume in both PDF and DOCX formats." },
  { question: "How long does it take to receive my professionally written CV?", answer: "Basic (48 hours), Pro (24 hours), Premium (12 hours), Express (24 hours guaranteed)." },
  { question: "What if I'm not satisfied with the CV?", answer: "We offer revisions with every plan. Basic includes 1 revision, Pro and Premium offer unlimited revisions. We also offer a money-back guarantee within 7 days." },
  { question: "Is my data secure?", answer: "We use bank-level encryption (SSL/TLS). Your information is stored securely and never shared with third parties. We are fully GDPR compliant." },
]

export function FAQSection() {
  return (
    <section id="faq" className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Find answers to common questions</p>
        </div>
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-foreground hover:text-primary">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
